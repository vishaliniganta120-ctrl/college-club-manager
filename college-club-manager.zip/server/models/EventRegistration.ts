import mongoose, { Schema, Document } from 'mongoose';
import { IEventRegistration } from '../types/index.ts';

export interface EventRegistrationDocument extends Omit<IEventRegistration, '_id'>, Document {}

const EventRegistrationSchema = new Schema<EventRegistrationDocument>(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    event: { type: Schema.Types.ObjectId, ref: 'Event', required: true },
    status: {
      type: String,
      enum: ['confirmed', 'waitlist', 'cancelled'],
      default: 'confirmed',
    },
    attendanceStatus: {
      type: String,
      enum: ['registered', 'attended', 'absent', 'cancelled'],
      default: 'registered',
    },
    registeredAt: { type: String, default: () => new Date().toISOString() },
  },
  {
    timestamps: true,
    toJSON: {
      transform(_doc, ret: Record<string, any>) {
        ret._id = ret._id ? ret._id.toString() : '';
        delete ret.__v;
        return ret;
      },
    },
  }
);

EventRegistrationSchema.index({ user: 1, event: 1 }, { unique: true });

export const EventRegistrationModel =
  mongoose.models.EventRegistration ||
  mongoose.model<EventRegistrationDocument>('EventRegistration', EventRegistrationSchema);
