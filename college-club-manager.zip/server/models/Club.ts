import mongoose, { Schema, Document } from 'mongoose';
import { IClub } from '../types/index.ts';

export interface ClubDocument extends Omit<IClub, '_id'>, Document {}

const ClubSchema = new Schema<ClubDocument>(
  {
    name: { type: String, required: true, trim: true, unique: true },
    description: { type: String, required: true },
    category: {
      type: String,
      required: true,
      enum: [
        'Technology',
        'Cultural & Arts',
        'Sports & Athletics',
        'Academic & Literary',
        'Entrepreneurship',
        'Media & Photography',
        'Social Impact',
      ],
    },
    logo: { type: String },
    image: { type: String },
    coordinator: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    membersCount: { type: Number, default: 0 },
  },
  {
    timestamps: true,
    toJSON: {
      transform(_doc, ret: Record<string, any>) {
        ret._id = ret._id ? ret._id.toString() : '';
        delete ret.__v;
        return ret;
      },
    },
  }
);

export const ClubModel = mongoose.models.Club || mongoose.model<ClubDocument>('Club', ClubSchema);
