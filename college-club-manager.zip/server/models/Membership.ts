import mongoose, { Schema, Document } from 'mongoose';
import { IMembership } from '../types/index.ts';

export interface MembershipDocument extends Omit<IMembership, '_id'>, Document {}

const MembershipSchema = new Schema<MembershipDocument>(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    club: { type: Schema.Types.ObjectId, ref: 'Club', required: true },
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected'],
      default: 'pending',
    },
    joinedAt: { type: String, default: () => new Date().toISOString() },
  },
  {
    timestamps: true,
    toJSON: {
      transform(_doc, ret: Record<string, any>) {
        ret._id = ret._id ? ret._id.toString() : '';
        delete ret.__v;
        return ret;
      },
    },
  }
);

// Compound uniqueness index to prevent duplicate active/pending membership requests
MembershipSchema.index({ user: 1, club: 1 }, { unique: true });

export const MembershipModel =
  mongoose.models.Membership || mongoose.model<MembershipDocument>('Membership', MembershipSchema);
