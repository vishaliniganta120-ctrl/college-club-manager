import mongoose, { Schema, Document } from 'mongoose';
import { IAnnouncement } from '../types/index.ts';

export interface AnnouncementDocument extends Omit<IAnnouncement, '_id'>, Document {}

const AnnouncementSchema = new Schema<AnnouncementDocument>(
  {
    title: { type: String, required: true, trim: true },
    message: { type: String, required: true },
    club: { type: Schema.Types.ObjectId, ref: 'Club' },
    priority: {
      type: String,
      enum: ['normal', 'important', 'urgent'],
      default: 'normal',
    },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    createdAt: { type: String, default: () => new Date().toISOString() },
  },
  {
    timestamps: true,
    toJSON: {
      transform(_doc, ret: Record<string, any>) {
        ret._id = ret._id ? ret._id.toString() : '';
        delete ret.__v;
        return ret;
      },
    },
  }
);

export const AnnouncementModel =
  mongoose.models.Announcement ||
  mongoose.model<AnnouncementDocument>('Announcement', AnnouncementSchema);
