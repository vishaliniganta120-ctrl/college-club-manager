import mongoose, { Schema, Document } from 'mongoose';
import { IEvent } from '../types/index.ts';

export interface EventDocument extends Omit<IEvent, '_id'>, Document {}

const EventSchema = new Schema<EventDocument>(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true },
    club: { type: Schema.Types.ObjectId, ref: 'Club', required: true },
    date: { type: String, required: true },
    time: { type: String, required: true },
    venue: { type: String, required: true },
    capacity: { type: Number, required: true, min: 1 },
    registrationsCount: { type: Number, default: 0 },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    image: { type: String },
  },
  {
    timestamps: true,
    toJSON: {
      transform(_doc, ret: Record<string, any>) {
        ret._id = ret._id ? ret._id.toString() : '';
        delete ret.__v;
        return ret;
      },
    },
  }
);

export const EventModel = mongoose.models.Event || mongoose.model<EventDocument>('Event', EventSchema);
