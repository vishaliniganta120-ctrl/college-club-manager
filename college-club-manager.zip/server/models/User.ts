import mongoose, { Schema, Document } from 'mongoose';
import { IUser, UserRole } from '../types/index.ts';

export interface UserDocument extends Omit<IUser, '_id'>, Document {}

const UserSchema = new Schema<UserDocument>(
  {
    name: { type: String, required: true, trim: true },
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },
    passwordHash: { type: String, required: true },
    studentId: {
      type: String,
      trim: true,
      sparse: true,
      index: { unique: true, sparse: true },
    },
    department: { type: String, trim: true },
    year: { type: Number, min: 1, max: 6 },
    role: {
      type: String,
      enum: ['student', 'coordinator', 'admin'] as UserRole[],
      default: 'student',
    },
    avatar: { type: String },
  },
  {
    timestamps: true,
    toJSON: {
      transform(_doc, ret: Record<string, any>) {
        ret._id = ret._id ? ret._id.toString() : '';
        delete ret.passwordHash;
        delete ret.__v;
        return ret;
      },
    },
  }
);

export const UserModel = mongoose.models.User || mongoose.model<UserDocument>('User', UserSchema);
