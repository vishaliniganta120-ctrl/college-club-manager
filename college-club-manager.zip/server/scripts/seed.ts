import dotenv from 'dotenv';
dotenv.config();

import { store } from '../services/dataStore.ts';
import { connectDB } from '../config/db.ts';

async function runSeed() {
  console.log('🚀 Running College Club Manager database seed script...');
  await connectDB();
  store.resetSeedData();
  console.log('🎉 Seed script executed successfully!');
  process.exit(0);
}

runSeed().catch((err) => {
  console.error('❌ Seed script error:', err);
  process.exit(1);
});
