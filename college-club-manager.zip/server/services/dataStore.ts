import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  IUser,
  IClub,
  IMembership,
  IEvent,
  IEventRegistration,
  IAnnouncement,
  UserRole,
} from '../types/index.ts';

interface StoreData {
  users: IUser[];
  clubs: IClub[];
  memberships: IMembership[];
  events: IEvent[];
  registrations: IEventRegistration[];
  announcements: IAnnouncement[];
}

const DATA_FILE = path.resolve(process.cwd(), '.data-store.json');

export class DataStore {
  private data: StoreData = {
    users: [],
    clubs: [],
    memberships: [],
    events: [],
    registrations: [],
    announcements: [],
  };

  constructor() {
    this.loadFromFile();
    if (this.data.users.length === 0) {
      this.seedInitialData();
    }
  }

  private loadFromFile() {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        this.data = JSON.parse(raw);
        console.log('📦 Loaded existing database store from disk.');
      }
    } catch (err) {
      console.warn('Could not read existing store file, initializing fresh:', err);
    }
  }

  private saveToFile() {
    try {
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.warn('Failed to persist store to file:', err);
    }
  }

  public resetSeedData() {
    this.seedInitialData();
  }

  private seedInitialData() {
    console.log('🌱 Seeding initial college club data...');
    const salt = bcrypt.genSaltSync(10);
    const hash = (pwd: string) => bcrypt.hashSync(pwd, salt);

    // Users
    const users: IUser[] = [
      {
        _id: 'usr_admin_1',
        name: 'Dr. P. Ramana Reddy (Dean & Registrar)',
        email: 'admin@college.edu',
        passwordHash: hash('Admin@123'),
        role: 'admin',
        department: 'Malla Reddy Vishwavidyapeeth Central Administration',
        createdAt: '2026-01-10T08:00:00.000Z',
      },
      {
        _id: 'usr_coord_1',
        name: 'Prof. K. Sridhar',
        email: 'sarah.chen@college.edu',
        passwordHash: hash('Coord@123'),
        role: 'coordinator',
        department: 'Computer Science & Engineering (MRV)',
        studentId: 'MRV-FAC-CS104',
        year: 4,
        createdAt: '2026-01-12T09:00:00.000Z',
      },
      {
        _id: 'usr_coord_2',
        name: 'Coach R. Srinivas',
        email: 'marcus.vance@college.edu',
        passwordHash: hash('Coord@123'),
        role: 'coordinator',
        department: 'Athletics & Physical Education (MRV)',
        studentId: 'MRV-FAC-PE208',
        year: 3,
        createdAt: '2026-01-14T10:00:00.000Z',
      },
      {
        _id: 'usr_coord_3',
        name: 'Dr. Sunitha Sharma (Cultural Convener)',
        email: 'aisha.m@college.edu',
        passwordHash: hash('Coord@123'),
        role: 'coordinator',
        department: 'Cultural Affairs & Bathukamma Committee',
        studentId: 'MRV-FAC-CUL312',
        year: 4,
        createdAt: '2026-01-15T11:00:00.000Z',
      },
      {
        _id: 'usr_student_1',
        name: 'Sai Teja Varma',
        email: 'alex.rivera@college.edu',
        passwordHash: hash('Student@123'),
        role: 'student',
        studentId: 'MRV24CS042',
        department: 'Computer Science & Engg',
        year: 3,
        createdAt: '2026-02-01T14:20:00.000Z',
      },
      {
        _id: 'usr_student_2',
        name: 'Sravani Reddy',
        email: 'priya.patel@college.edu',
        passwordHash: hash('Student@123'),
        role: 'student',
        studentId: 'MRV23EC019',
        department: 'Electronics & Comm. Engg',
        year: 4,
        createdAt: '2026-02-02T15:30:00.000Z',
      },
      {
        _id: 'usr_student_3',
        name: 'Karthik Rao',
        email: 'david.kim@college.edu',
        passwordHash: hash('Student@123'),
        role: 'student',
        studentId: 'MRV25ME081',
        department: 'Mechanical Engineering',
        year: 2,
        createdAt: '2026-02-05T10:10:00.000Z',
      },
      {
        _id: 'usr_student_4',
        name: 'Ananya Deshmukh',
        email: 'maya.lin@college.edu',
        passwordHash: hash('Student@123'),
        role: 'student',
        studentId: 'MRV24AI012',
        department: 'CSE - Artificial Intelligence & ML',
        year: 3,
        createdAt: '2026-02-08T11:45:00.000Z',
      },
      {
        _id: 'usr_student_5',
        name: 'Rohit Kulkarni',
        email: 'liam.j@college.edu',
        passwordHash: hash('Student@123'),
        role: 'student',
        studentId: 'MRV25MB067',
        department: 'School of Management (MBA)',
        year: 2,
        createdAt: '2026-02-10T16:00:00.000Z',
      },
    ];

    // Clubs
    const clubs: IClub[] = [
      {
        _id: 'club_coding',
        name: 'Coding Club',
        description: 'Fosters hands-on software development, competitive programming, open source projects, and national hackathon participation for developers of all skill levels.',
        category: 'Technology',
        coordinator: 'usr_coord_1',
        image: '/src/assets/images/club_coding_showcase_1791569529938.jpg',
        createdAt: '2026-01-16T10:00:00.000Z',
      },
      {
        _id: 'club_robotics',
        name: 'Robotics Club',
        description: 'Specializes in autonomous mobile robots, microcontrollers, computer vision, and national collegiate robotics challenges with hands-on lab access.',
        category: 'Technology',
        coordinator: 'usr_coord_1',
        createdAt: '2026-01-17T11:00:00.000Z',
      },
      {
        _id: 'club_cultural',
        name: 'Cultural Club',
        description: 'Celebrates global diversity, musical heritage, theatrical drama, folk dances, and coordinates our flagship inter-collegiate annual cultural fest.',
        category: 'Cultural & Arts',
        coordinator: 'usr_coord_3',
        image: '/src/assets/images/club_cultural_arts_1791569541483.jpg',
        createdAt: '2026-01-18T12:00:00.000Z',
      },
      {
        _id: 'club_photography',
        name: 'Photography Club',
        description: 'Teaches digital photography, studio lighting, visual storytelling, and photowalks across campus while documenting major collegiate activities.',
        category: 'Media & Photography',
        coordinator: 'usr_coord_3',
        createdAt: '2026-01-19T13:00:00.000Z',
      },
      {
        _id: 'club_literary',
        name: 'Literary Club',
        description: 'A welcoming forum for parliamentary debates, creative prose writing, poetry slams, monthly book discussions, and campus editorial publications.',
        category: 'Academic & Literary',
        coordinator: 'usr_coord_3',
        createdAt: '2026-01-20T14:00:00.000Z',
      },
      {
        _id: 'club_sports',
        name: 'Sports Club',
        description: 'Organizes intra-college leagues, athletic fitness sessions, badminton, soccer, basketball, and represents the institution in collegiate tournaments.',
        category: 'Sports & Athletics',
        coordinator: 'usr_coord_2',
        image: '/src/assets/images/club_sports_field_1791569553520.jpg',
        createdAt: '2026-01-21T15:00:00.000Z',
      },
      {
        _id: 'club_entrepreneurship',
        name: 'Entrepreneurship Club',
        description: 'Empowers student founders through venture pitch competitions, startup incubation mentorship, angel investor talks, and market validation bootcamps.',
        category: 'Entrepreneurship',
        coordinator: 'usr_coord_1',
        createdAt: '2026-01-22T16:00:00.000Z',
      },
      {
        _id: 'club_music_dance',
        name: 'Music and Dance Club',
        description: 'Brings together vocalists, acoustic and electric instrumentalists, and dance troupes for live jam sessions and campus-wide performances.',
        category: 'Cultural & Arts',
        coordinator: 'usr_coord_3',
        createdAt: '2026-01-23T17:00:00.000Z',
      },
    ];

    // Memberships
    const memberships: IMembership[] = [
      // Alex Rivera memberships
      {
        _id: 'mem_1',
        user: 'usr_student_1',
        club: 'club_coding',
        status: 'approved',
        joinedAt: '2026-02-02T10:00:00.000Z',
      },
      {
        _id: 'mem_2',
        user: 'usr_student_1',
        club: 'club_robotics',
        status: 'approved',
        joinedAt: '2026-02-04T12:00:00.000Z',
      },
      {
        _id: 'mem_3',
        user: 'usr_student_1',
        club: 'club_photography',
        status: 'pending',
        joinedAt: '2026-10-01T15:00:00.000Z',
      },
      // Priya Patel memberships
      {
        _id: 'mem_4',
        user: 'usr_student_2',
        club: 'club_coding',
        status: 'approved',
        joinedAt: '2026-02-03T11:00:00.000Z',
      },
      {
        _id: 'mem_5',
        user: 'usr_student_2',
        club: 'club_entrepreneurship',
        status: 'approved',
        joinedAt: '2026-02-10T14:00:00.000Z',
      },
      // David Kim memberships
      {
        _id: 'mem_6',
        user: 'usr_student_3',
        club: 'club_sports',
        status: 'approved',
        joinedAt: '2026-02-06T12:00:00.000Z',
      },
      {
        _id: 'mem_7',
        user: 'usr_student_3',
        club: 'club_robotics',
        status: 'pending',
        joinedAt: '2026-10-02T09:30:00.000Z',
      },
      // Maya Lin memberships
      {
        _id: 'mem_8',
        user: 'usr_student_4',
        club: 'club_cultural',
        status: 'approved',
        joinedAt: '2026-02-12T16:00:00.000Z',
      },
      {
        _id: 'mem_9',
        user: 'usr_student_4',
        club: 'club_music_dance',
        status: 'approved',
        joinedAt: '2026-02-14T18:00:00.000Z',
      },
      // Liam Johnson memberships
      {
        _id: 'mem_10',
        user: 'usr_student_5',
        club: 'club_entrepreneurship',
        status: 'approved',
        joinedAt: '2026-02-15T11:00:00.000Z',
      },
      {
        _id: 'mem_11',
        user: 'usr_student_5',
        club: 'club_literary',
        status: 'pending',
        joinedAt: '2026-10-03T14:15:00.000Z',
      },
    ];

    // Events
    const events: IEvent[] = [
      {
        _id: 'evt_dandiya_mrv',
        title: 'Malla Reddy Vishwavidyapeeth Mega Dandiya & Garba Raas Night 2026',
        description: 'Celebrate the rhythmic joy of Navratri with electrifying live Dhol, authentic Gujarati Garba Raas, and high-energy Bollywood DJ beats! Free decorative Dandiya sticks provided at entrance. Competitions for Best Dandiya Dancer and Best Traditional Attire with cash prizes. Authentic street food stalls and festive lighting across campus. Traditional dress code mandatory.',
        club: 'club_cultural',
        date: '2026-10-18',
        time: '06:00 PM',
        venue: 'University Central Cricket Lawns & Open Amphitheatre',
        capacity: 600,
        createdBy: 'usr_coord_3',
        image: '/src/assets/images/dandiya_night_festival_1791571677852.jpg',
        createdAt: '2026-10-06T10:00:00.000Z',
      },
      {
        _id: 'evt_bathukamma_mrv',
        title: 'Saddula Bathukamma Mahotsavam & Floral Rangoli Grand Celebration',
        description: 'Telangana’s proud state festival of flowers celebrated grandly at Malla Reddy Vishwavidyapeeth! Features inter-department Bathukamma floral pyramid design contest using Gunugu and Thangedu flowers, traditional folk singing circles, Potharaju dance performance, and campus Maha Aarti followed by ceremonial nimajjanam.',
        club: 'club_cultural',
        date: '2026-10-15',
        time: '02:00 PM',
        venue: 'Central Administrative Courtyard & Heritage Lawn',
        capacity: 450,
        createdBy: 'usr_coord_3',
        image: '/src/assets/images/bathukamma_celebration_mrv_1791571690625.jpg',
        createdAt: '2026-10-05T09:00:00.000Z',
      },
      {
        _id: 'evt_1',
        title: 'Annual 24-Hour Collegiate Hackathon',
        description: 'Build impactful real-world software applications and hardware hacks in 24 hours. Includes mentoring from senior software architects, free meals, and cash prizes.',
        club: 'club_coding',
        date: '2026-10-24',
        time: '09:00 AM',
        venue: 'Engineering Hall Room 401 & Central Atrium',
        capacity: 80,
        createdBy: 'usr_coord_1',
        image: '/src/assets/images/club_coding_showcase_1791569529938.jpg',
        createdAt: '2026-09-15T09:00:00.000Z',
      },
      {
        _id: 'evt_2',
        title: 'Autonomous Rover & Drone Showcase',
        description: 'Demonstrations of student-built obstacle-avoiding rovers and telemetry drones with interactive Q&A and hardware flight testing.',
        club: 'club_robotics',
        date: '2026-10-28',
        time: '02:00 PM',
        venue: 'Robotics Workshop, Ground Floor Tech Center',
        capacity: 45,
        createdBy: 'usr_coord_1',
        createdAt: '2026-09-20T10:00:00.000Z',
      },
      {
        _id: 'evt_3',
        title: 'Autumn Stage & Acoustic Live Jam',
        description: 'An acoustic musical evening featuring student bands, classical strings, and open mic performances under the autumn campus lights.',
        club: 'club_cultural',
        date: '2026-11-04',
        time: '05:30 PM',
        venue: 'Main Auditorium & Amphitheater',
        capacity: 150,
        createdBy: 'usr_coord_3',
        image: '/src/assets/images/club_cultural_arts_1791569541483.jpg',
        createdAt: '2026-09-25T11:00:00.000Z',
      },
      {
        _id: 'evt_4',
        title: 'Inter-Department 7v7 Soccer Championship',
        description: 'The annual fall cup between academic departments. Fast-paced 7-a-side matches with official referees and medals.',
        club: 'club_sports',
        date: '2026-11-12',
        time: '08:30 AM',
        venue: 'Collegiate Athletic Stadium & Turf',
        capacity: 60,
        createdBy: 'usr_coord_2',
        image: '/src/assets/images/club_sports_field_1791569553520.jpg',
        createdAt: '2026-09-28T12:00:00.000Z',
      },
      {
        _id: 'evt_5',
        title: 'Startup Pitch Deck & Angel Investor Night',
        description: 'Student founders pitch early-stage prototypes to local startup founders and alumni angel investors. Feedback and networking reception follows.',
        club: 'club_entrepreneurship',
        date: '2026-11-18',
        time: '04:00 PM',
        venue: 'Student Hub & Innovation Conference Room B',
        capacity: 50,
        createdBy: 'usr_coord_1',
        createdAt: '2026-10-01T08:00:00.000Z',
      },
      {
        _id: 'evt_6',
        title: 'Golden Hour Campus Architectural Photowalk',
        description: 'Guided photowalk focusing on architectural composition, golden-hour natural shadows, and post-processing fundamentals.',
        club: 'club_photography',
        date: '2026-11-22',
        time: '04:30 PM',
        venue: 'Campus Clock Tower Plaza Meetup',
        capacity: 30,
        createdBy: 'usr_coord_3',
        createdAt: '2026-10-02T13:00:00.000Z',
      },
    ];

    // Registrations
    const registrations: IEventRegistration[] = [
      {
        _id: 'reg_dandiya_1',
        user: 'usr_student_1',
        event: 'evt_dandiya_mrv',
        status: 'confirmed',
        attendanceStatus: 'registered',
        registeredAt: '2026-10-07T10:00:00.000Z',
      },
      {
        _id: 'reg_bathukamma_1',
        user: 'usr_student_2',
        event: 'evt_bathukamma_mrv',
        status: 'confirmed',
        attendanceStatus: 'registered',
        registeredAt: '2026-10-07T11:00:00.000Z',
      },
      {
        _id: 'reg_1',
        user: 'usr_student_1',
        event: 'evt_1',
        status: 'confirmed',
        attendanceStatus: 'registered',
        registeredAt: '2026-09-20T10:15:00.000Z',
      },
      {
        _id: 'reg_2',
        user: 'usr_student_2',
        event: 'evt_1',
        status: 'confirmed',
        attendanceStatus: 'registered',
        registeredAt: '2026-09-21T11:20:00.000Z',
      },
      {
        _id: 'reg_3',
        user: 'usr_student_3',
        event: 'evt_4',
        status: 'confirmed',
        attendanceStatus: 'registered',
        registeredAt: '2026-09-29T14:00:00.000Z',
      },
      {
        _id: 'reg_4',
        user: 'usr_student_4',
        event: 'evt_3',
        status: 'confirmed',
        attendanceStatus: 'registered',
        registeredAt: '2026-09-30T16:30:00.000Z',
      },
      {
        _id: 'reg_5',
        user: 'usr_student_5',
        event: 'evt_5',
        status: 'confirmed',
        attendanceStatus: 'registered',
        registeredAt: '2026-10-02T10:00:00.000Z',
      },
      {
        _id: 'reg_6',
        user: 'usr_student_1',
        event: 'evt_2',
        status: 'confirmed',
        attendanceStatus: 'registered',
        registeredAt: '2026-10-03T11:00:00.000Z',
      },
    ];

    // Announcements
    const announcements: IAnnouncement[] = [
      {
        _id: 'ann_dandiya',
        title: '🎉 Mega Dandiya & Garba Raas Night 2026 at Malla Reddy Vishwavidyapeeth!',
        message: 'Join us on 18th October at the University Cricket Grounds for our grandest festive night of the year! Live Dhol artists, celebrity DJ beats, food stalls, and prizes for Best Traditional Dancer. Free Dandiya sticks provided. Gates open at 5:30 PM. Traditional ethnic attire is mandatory.',
        club: 'club_cultural',
        priority: 'urgent',
        createdBy: 'usr_admin_1',
        createdAt: '2026-10-08T09:00:00.000Z',
      },
      {
        _id: 'ann_bathukamma',
        title: '🌸 Saddula Bathukamma Mahotsavam & Floral Rangoli Competition Announced',
        message: 'Celebrate Telangana pride on 15th October at the Central Courtyard! Inter-departmental floral pyramid making competition with trophies and cash awards. Traditional folk dances, Potharaju performance, and Maha Aarti. Register your departmental student teams now.',
        club: 'club_cultural',
        priority: 'important',
        createdBy: 'usr_coord_3',
        createdAt: '2026-10-07T11:30:00.000Z',
      },
      {
        _id: 'ann_1',
        title: 'Semester Club Registration Window is Open',
        message: 'All students across engineering, management, and sciences are invited to explore clubs and submit membership requests. Clubs review applications on a rolling weekly basis.',
        priority: 'normal',
        createdBy: 'usr_admin_1',
        createdAt: '2026-10-01T09:00:00.000Z',
      },
      {
        _id: 'ann_2',
        title: 'Annual Hackathon Team Formations & Mentorship Track',
        message: 'Coding Club has published mentor schedules and problem statements for the upcoming 24-hour hackathon. Register early as capacity is capped at 80 participants.',
        club: 'club_coding',
        priority: 'important',
        createdBy: 'usr_coord_1',
        createdAt: '2026-10-03T14:30:00.000Z',
      },
    ];

    this.data = {
      users,
      clubs,
      memberships,
      events,
      registrations,
      announcements,
    };

    this.saveToFile();
    console.log('✅ Seed completed successfully with 9 users, 8 clubs, 6 events, and active memberships.');
  }

  // --- Users Operations ---
  public getUsers(): IUser[] {
    return this.data.users.map((u) => {
      const { passwordHash, ...rest } = u;
      return rest as IUser;
    });
  }

  public getUserById(id: string): IUser | undefined {
    return this.data.users.find((u) => u._id === id);
  }

  public getUserByEmail(email: string): IUser | undefined {
    return this.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public getUserByStudentId(studentId: string): IUser | undefined {
    return this.data.users.find((u) => u.studentId && u.studentId.toLowerCase() === studentId.toLowerCase());
  }

  public createUser(userData: Partial<IUser> & { password: string }): IUser {
    const { password, ...fields } = userData;
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);

    const newUser: IUser = {
      _id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: fields.name || '',
      email: fields.email!.toLowerCase(),
      passwordHash,
      studentId: fields.studentId,
      department: fields.department,
      year: fields.year,
      role: fields.role || 'student',
      avatar: fields.avatar,
      createdAt: new Date().toISOString(),
    };

    this.data.users.push(newUser);
    this.saveToFile();
    return newUser;
  }

  public updateUser(id: string, updates: Partial<IUser> & { newPassword?: string }): IUser | null {
    const index = this.data.users.findIndex((u) => u._id === id);
    if (index === -1) return null;

    const current = this.data.users[index];
    let passwordHash = current.passwordHash;
    if (updates.newPassword) {
      const salt = bcrypt.genSaltSync(10);
      passwordHash = bcrypt.hashSync(updates.newPassword, salt);
    }

    const updated: IUser = {
      ...current,
      ...updates,
      passwordHash,
      updatedAt: new Date().toISOString(),
    };

    this.data.users[index] = updated;
    this.saveToFile();
    return updated;
  }

  public deleteUser(id: string): boolean {
    const prevLen = this.data.users.length;
    this.data.users = this.data.users.filter((u) => u._id !== id);
    // also clean up memberships and registrations
    this.data.memberships = this.data.memberships.filter((m) => m.user !== id);
    this.data.registrations = this.data.registrations.filter((r) => r.user !== id);
    this.saveToFile();
    return this.data.users.length < prevLen;
  }

  // --- Clubs Operations ---
  public getClubs(): IClub[] {
    return this.data.clubs.map((c) => {
      const coord = this.getUserById(c.coordinator as string);
      const membersCount = this.data.memberships.filter(
        (m) => m.club === c._id && m.status === 'approved'
      ).length;
      return {
        ...c,
        coordinator: coord
          ? {
              _id: coord._id,
              name: coord.name,
              email: coord.email,
              role: coord.role,
              department: coord.department,
            }
          : c.coordinator,
        membersCount,
      } as IClub;
    });
  }

  public getClubById(id: string): IClub | undefined {
    const c = this.data.clubs.find((club) => club._id === id);
    if (!c) return undefined;

    const coord = this.getUserById(c.coordinator as string);
    const membersCount = this.data.memberships.filter(
      (m) => m.club === c._id && m.status === 'approved'
    ).length;

    return {
      ...c,
      coordinator: coord
        ? {
            _id: coord._id,
            name: coord.name,
            email: coord.email,
            role: coord.role,
            department: coord.department,
          }
        : c.coordinator,
      membersCount,
    } as IClub;
  }

  public createClub(clubData: Omit<IClub, '_id' | 'createdAt'>): IClub {
    const newClub: IClub = {
      _id: `club_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: clubData.name,
      description: clubData.description,
      category: clubData.category,
      logo: clubData.logo,
      image: clubData.image,
      coordinator: clubData.coordinator,
      createdAt: new Date().toISOString(),
    };
    this.data.clubs.push(newClub);
    this.saveToFile();
    return newClub;
  }

  public updateClub(id: string, updates: Partial<IClub>): IClub | null {
    const index = this.data.clubs.findIndex((c) => c._id === id);
    if (index === -1) return null;

    const current = this.data.clubs[index];
    const updated: IClub = {
      ...current,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    this.data.clubs[index] = updated;
    this.saveToFile();
    return updated;
  }

  public deleteClub(id: string): boolean {
    const prevLen = this.data.clubs.length;
    this.data.clubs = this.data.clubs.filter((c) => c._id !== id);
    // Cleanup events, memberships, announcements
    this.data.events = this.data.events.filter((e) => e.club !== id);
    this.data.memberships = this.data.memberships.filter((m) => m.club !== id);
    this.data.announcements = this.data.announcements.filter((a) => a.club !== id);
    this.saveToFile();
    return this.data.clubs.length < prevLen;
  }

  // --- Memberships Operations ---
  public getMemberships(filter?: { userId?: string; clubId?: string; status?: string }): IMembership[] {
    return this.data.memberships
      .filter((m) => {
        if (filter?.userId && m.user !== filter.userId) return false;
        if (filter?.clubId && m.club !== filter.clubId) return false;
        if (filter?.status && m.status !== filter.status) return false;
        return true;
      })
      .map((m) => {
        const user = this.getUserById(m.user as string);
        const club = this.data.clubs.find((c) => c._id === m.club);
        return {
          ...m,
          user: user
            ? {
                _id: user._id,
                name: user.name,
                email: user.email,
                studentId: user.studentId,
                department: user.department,
                year: user.year,
                role: user.role,
              }
            : m.user,
          club: club
            ? {
                _id: club._id,
                name: club.name,
                category: club.category,
                image: club.image,
              }
            : m.club,
        } as IMembership;
      });
  }

  public findActiveMembership(userId: string, clubId: string): IMembership | undefined {
    return this.data.memberships.find(
      (m) => m.user === userId && m.club === clubId && (m.status === 'approved' || m.status === 'pending')
    );
  }

  public createMembership(userId: string, clubId: string): IMembership {
    const newMembership: IMembership = {
      _id: `mem_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      user: userId,
      club: clubId,
      status: 'pending',
      joinedAt: new Date().toISOString(),
    };
    this.data.memberships.push(newMembership);
    this.saveToFile();
    return newMembership;
  }

  public updateMembershipStatus(id: string, status: 'approved' | 'rejected'): IMembership | null {
    const index = this.data.memberships.findIndex((m) => m._id === id);
    if (index === -1) return null;

    this.data.memberships[index].status = status;
    this.data.memberships[index].updatedAt = new Date().toISOString();
    this.saveToFile();
    return this.data.memberships[index];
  }

  public deleteMembership(id: string): boolean {
    const prev = this.data.memberships.length;
    this.data.memberships = this.data.memberships.filter((m) => m._id !== id);
    this.saveToFile();
    return this.data.memberships.length < prev;
  }

  // --- Events Operations ---
  public getEvents(): IEvent[] {
    return this.data.events.map((e) => {
      const club = this.data.clubs.find((c) => c._id === e.club);
      const creator = this.getUserById(e.createdBy as string);
      const registrationsCount = this.data.registrations.filter(
        (r) => r.event === e._id && r.status === 'confirmed'
      ).length;

      return {
        ...e,
        registrationsCount,
        club: club
          ? {
              _id: club._id,
              name: club.name,
              category: club.category,
            }
          : e.club,
        createdBy: creator
          ? {
              _id: creator._id,
              name: creator.name,
              email: creator.email,
            }
          : e.createdBy,
      } as IEvent;
    });
  }

  public getEventById(id: string): IEvent | undefined {
    const e = this.data.events.find((evt) => evt._id === id);
    if (!e) return undefined;

    const club = this.data.clubs.find((c) => c._id === e.club);
    const creator = this.getUserById(e.createdBy as string);
    const registrationsCount = this.data.registrations.filter(
      (r) => r.event === e._id && r.status === 'confirmed'
    ).length;

    return {
      ...e,
      registrationsCount,
      club: club
        ? {
            _id: club._id,
            name: club.name,
            category: club.category,
          }
        : e.club,
      createdBy: creator
        ? {
            _id: creator._id,
            name: creator.name,
            email: creator.email,
          }
        : e.createdBy,
    } as IEvent;
  }

  public createEvent(eventData: Omit<IEvent, '_id' | 'createdAt'>): IEvent {
    const newEvent: IEvent = {
      _id: `evt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      title: eventData.title,
      description: eventData.description,
      club: eventData.club,
      date: eventData.date,
      time: eventData.time,
      venue: eventData.venue,
      capacity: Number(eventData.capacity),
      createdBy: eventData.createdBy,
      image: eventData.image,
      createdAt: new Date().toISOString(),
    };

    this.data.events.push(newEvent);
    this.saveToFile();
    return newEvent;
  }

  public updateEvent(id: string, updates: Partial<IEvent>): IEvent | null {
    const index = this.data.events.findIndex((e) => e._id === id);
    if (index === -1) return null;

    const updated = {
      ...this.data.events[index],
      ...updates,
      capacity: updates.capacity !== undefined ? Number(updates.capacity) : this.data.events[index].capacity,
    };
    this.data.events[index] = updated;
    this.saveToFile();
    return updated;
  }

  public deleteEvent(id: string): boolean {
    const prev = this.data.events.length;
    this.data.events = this.data.events.filter((e) => e._id !== id);
    this.data.registrations = this.data.registrations.filter((r) => r.event !== id);
    this.saveToFile();
    return this.data.events.length < prev;
  }

  // --- Event Registrations Operations ---
  public getRegistrations(filter?: { userId?: string; eventId?: string }): IEventRegistration[] {
    return this.data.registrations
      .filter((r) => {
        if (filter?.userId && r.user !== filter.userId) return false;
        if (filter?.eventId && r.event !== filter.eventId) return false;
        return true;
      })
      .map((r) => {
        const user = this.getUserById(r.user as string);
        const event = this.getEventById(r.event as string);
        return {
          ...r,
          user: user
            ? {
                _id: user._id,
                name: user.name,
                email: user.email,
                studentId: user.studentId,
                department: user.department,
                year: user.year,
              }
            : r.user,
          event: event
            ? {
                _id: event._id,
                title: event.title,
                date: event.date,
                time: event.time,
                venue: event.venue,
                club: event.club,
              }
            : r.event,
        } as IEventRegistration;
      });
  }

  public findExistingRegistration(userId: string, eventId: string): IEventRegistration | undefined {
    return this.data.registrations.find(
      (r) => r.user === userId && r.event === eventId && r.status !== 'cancelled'
    );
  }

  public createRegistration(userId: string, eventId: string): IEventRegistration {
    const newReg: IEventRegistration = {
      _id: `reg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      user: userId,
      event: eventId,
      status: 'confirmed',
      attendanceStatus: 'registered',
      registeredAt: new Date().toISOString(),
    };
    this.data.registrations.push(newReg);
    this.saveToFile();
    return newReg;
  }

  public updateAttendanceStatus(
    id: string,
    attendanceStatus: 'registered' | 'attended' | 'absent' | 'cancelled'
  ): IEventRegistration | null {
    const index = this.data.registrations.findIndex((r) => r._id === id);
    if (index === -1) return null;

    this.data.registrations[index].attendanceStatus = attendanceStatus;
    if (attendanceStatus === 'cancelled') {
      this.data.registrations[index].status = 'cancelled';
    }
    this.saveToFile();
    return this.data.registrations[index];
  }

  public deleteRegistration(id: string): boolean {
    const prev = this.data.registrations.length;
    this.data.registrations = this.data.registrations.filter((r) => r._id !== id);
    this.saveToFile();
    return this.data.registrations.length < prev;
  }

  // --- Announcements Operations ---
  public getAnnouncements(clubId?: string): IAnnouncement[] {
    return this.data.announcements
      .filter((a) => {
        if (!clubId) return true;
        return a.club === clubId || !a.club;
      })
      .map((a) => {
        const creator = this.getUserById(a.createdBy as string);
        const club = a.club ? this.data.clubs.find((c) => c._id === a.club) : undefined;
        return {
          ...a,
          createdBy: creator
            ? {
                _id: creator._id,
                name: creator.name,
                role: creator.role,
              }
            : a.createdBy,
          club: club
            ? {
                _id: club._id,
                name: club.name,
              }
            : undefined,
        } as IAnnouncement;
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public createAnnouncement(data: Omit<IAnnouncement, '_id' | 'createdAt'>): IAnnouncement {
    const newAnn: IAnnouncement = {
      _id: `ann_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      title: data.title,
      message: data.message,
      club: data.club,
      priority: data.priority || 'normal',
      createdBy: data.createdBy,
      createdAt: new Date().toISOString(),
    };
    this.data.announcements.push(newAnn);
    this.saveToFile();
    return newAnn;
  }

  public updateAnnouncement(id: string, updates: Partial<IAnnouncement>): IAnnouncement | null {
    const index = this.data.announcements.findIndex((a) => a._id === id);
    if (index === -1) return null;

    const updated = {
      ...this.data.announcements[index],
      ...updates,
    };
    this.data.announcements[index] = updated;
    this.saveToFile();
    return updated;
  }

  public deleteAnnouncement(id: string): boolean {
    const prev = this.data.announcements.length;
    this.data.announcements = this.data.announcements.filter((a) => a._id !== id);
    this.saveToFile();
    return this.data.announcements.length < prev;
  }

  // --- Reports & Analytics Operations ---
  public getDashboardStats() {
    const totalClubs = this.data.clubs.length;
    const totalStudents = this.data.users.filter((u) => u.role === 'student').length;
    const totalRegistrations = this.data.registrations.filter((r) => r.status === 'confirmed').length;
    const pendingMemberships = this.data.memberships.filter((m) => m.status === 'pending').length;

    const todayStr = new Date().toISOString().split('T')[0];
    const upcomingEvents = this.data.events
      .filter((e) => e.date >= todayStr)
      .sort((a, b) => a.date.localeCompare(b.date));

    // Department breakdown
    const deptMap: Record<string, number> = {};
    for (const user of this.data.users) {
      if (user.role === 'student' && user.department) {
        deptMap[user.department] = (deptMap[user.department] || 0) + 1;
      }
    }
    const departmentParticipation = Object.entries(deptMap).map(([department, count]) => ({
      department,
      count,
    }));

    // Most popular clubs
    const popularClubs = this.data.clubs.map((c) => {
      const activeMembers = this.data.memberships.filter(
        (m) => m.club === c._id && m.status === 'approved'
      ).length;
      return {
        _id: c._id,
        name: c.name,
        category: c.category,
        membersCount: activeMembers,
      };
    }).sort((a, b) => b.membersCount - a.membersCount);

    // Monthly event distribution
    const monthCounts: Record<string, number> = {
      'Sep 2026': 4,
      'Oct 2026': 2,
      'Nov 2026': 3,
      'Dec 2026': 1,
    };
    for (const evt of this.data.events) {
      const d = new Date(evt.date);
      if (!isNaN(d.getTime())) {
        const key = d.toLocaleString('en-US', { month: 'short', year: 'numeric' });
        monthCounts[key] = (monthCounts[key] || 0) + 1;
      }
    }
    const eventsByMonth = Object.entries(monthCounts).map(([month, count]) => ({
      month,
      events: count,
    }));

    return {
      summary: {
        totalClubs,
        totalStudents,
        upcomingEventsCount: upcomingEvents.length,
        totalRegistrations,
        pendingMemberships,
      },
      upcomingEvents: upcomingEvents.slice(0, 5),
      recentAnnouncements: this.getAnnouncements().slice(0, 4),
      departmentParticipation,
      popularClubs: popularClubs.slice(0, 6),
      eventsByMonth,
    };
  }
}

export const store = new DataStore();
