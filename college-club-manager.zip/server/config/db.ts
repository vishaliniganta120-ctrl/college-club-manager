import mongoose from 'mongoose';

let isConnected = false;
let connectionError: string | null = null;

export async function connectDB(): Promise<boolean> {
  const uri = process.env.MONGODB_URI;

  if (!uri) {
    console.log('ℹ️ MONGODB_URI not provided. Active in embedded document store mode.');
    isConnected = false;
    return false;
  }

  try {
    console.log('🔄 Connecting to MongoDB Atlas...');
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 5000,
    });
    isConnected = true;
    connectionError = null;
    console.log('✅ Connected to MongoDB Atlas successfully.');
    return true;
  } catch (err: any) {
    isConnected = false;
    connectionError = err.message || 'Unknown MongoDB connection error';
    console.warn('⚠️ MongoDB Atlas connection failed:', connectionError);
    console.warn('👉 Switching to embedded document store mode.');
    return false;
  }
}

export function getDBStatus() {
  return {
    connectedToAtlas: isConnected,
    mode: isConnected ? 'MongoDB Atlas (Live)' : 'Embedded Document Store (Local)',
    error: connectionError,
    mongooseReadyState: mongoose.connection.readyState,
  };
}
