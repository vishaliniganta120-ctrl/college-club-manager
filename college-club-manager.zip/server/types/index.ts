export type UserRole = 'student' | 'coordinator' | 'admin';

export interface IUser {
  _id: string;
  name: string;
  email: string;
  passwordHash: string;
  studentId?: string;
  department?: string;
  year?: number;
  role: UserRole;
  avatar?: string;
  createdAt: string;
  updatedAt?: string;
}

export type ClubCategory =
  | 'Technology'
  | 'Cultural & Arts'
  | 'Sports & Athletics'
  | 'Academic & Literary'
  | 'Entrepreneurship'
  | 'Media & Photography'
  | 'Social Impact';

export interface IClub {
  _id: string;
  name: string;
  description: string;
  category: ClubCategory;
  logo?: string;
  image?: string;
  coordinator: string | IUser; // User ID or populated IUser
  membersCount?: number;
  createdAt: string;
  updatedAt?: string;
}

export type MembershipStatus = 'pending' | 'approved' | 'rejected';

export interface IMembership {
  _id: string;
  user: string | IUser;
  club: string | IClub;
  status: MembershipStatus;
  joinedAt: string;
  updatedAt?: string;
}

export interface IEvent {
  _id: string;
  title: string;
  description: string;
  club: string | IClub;
  date: string;
  time: string;
  venue: string;
  capacity: number;
  registrationsCount?: number;
  createdBy: string | IUser;
  createdAt: string;
  image?: string;
}

export type AttendanceStatus = 'registered' | 'attended' | 'absent' | 'cancelled';

export interface IEventRegistration {
  _id: string;
  user: string | IUser;
  event: string | IEvent;
  status: 'confirmed' | 'waitlist' | 'cancelled';
  attendanceStatus: AttendanceStatus;
  registeredAt: string;
}

export interface IAnnouncement {
  _id: string;
  title: string;
  message: string;
  club?: string | IClub;
  priority?: 'normal' | 'important' | 'urgent';
  createdBy: string | IUser;
  createdAt: string;
}
