import { Router } from 'express';
import {
  getClubs,
  getClubById,
  createClub,
  updateClub,
  deleteClub,
} from '../controllers/clubController.ts';
import { authenticate, authorize } from '../middleware/auth.ts';

const router = Router();

router.get('/', getClubs);
router.get('/:id', getClubById);
router.post('/', authenticate, authorize('admin'), createClub);
router.put('/:id', authenticate, authorize('admin', 'coordinator'), updateClub);
router.delete('/:id', authenticate, authorize('admin'), deleteClub);

export default router;
