import { Router } from 'express';
import {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
} from '../controllers/userController.ts';
import { authenticate, authorize } from '../middleware/auth.ts';

const router = Router();

router.get('/', authenticate, authorize('admin', 'coordinator'), getAllUsers);
router.get('/:id', authenticate, getUserById);
router.put('/:id', authenticate, updateUser);
router.delete('/:id', authenticate, authorize('admin'), deleteUser);

export default router;
