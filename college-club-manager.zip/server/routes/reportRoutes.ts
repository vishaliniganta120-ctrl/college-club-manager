import { Router } from 'express';
import {
  getDashboardReport,
  getParticipationReport,
} from '../controllers/reportController.ts';

const router = Router();

router.get('/dashboard', getDashboardReport);
router.get('/participation', getParticipationReport);

export default router;
