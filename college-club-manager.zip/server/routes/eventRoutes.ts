import { Router } from 'express';
import {
  getEvents,
  getEventById,
  createEvent,
  updateEvent,
  deleteEvent,
} from '../controllers/eventController.ts';
import { authenticate, authorize } from '../middleware/auth.ts';

const router = Router();

router.get('/', getEvents);
router.get('/:id', getEventById);
router.post('/', authenticate, authorize('coordinator', 'admin'), createEvent);
router.put('/:id', authenticate, authorize('coordinator', 'admin'), updateEvent);
router.delete('/:id', authenticate, authorize('coordinator', 'admin'), deleteEvent);

export default router;
