import { Router } from 'express';
import {
  getAnnouncements,
  createAnnouncement,
  updateAnnouncement,
  deleteAnnouncement,
} from '../controllers/announcementController.ts';
import { authenticate, authorize } from '../middleware/auth.ts';

const router = Router();

router.get('/', getAnnouncements);
router.post('/', authenticate, authorize('coordinator', 'admin'), createAnnouncement);
router.put('/:id', authenticate, authorize('coordinator', 'admin'), updateAnnouncement);
router.delete('/:id', authenticate, authorize('coordinator', 'admin'), deleteAnnouncement);

export default router;
