import { Router } from 'express';
import {
  registerForEvent,
  getMyRegistrations,
  getEventRegistrations,
  updateAttendance,
  cancelRegistration,
} from '../controllers/registrationController.ts';
import { authenticate, authorize } from '../middleware/auth.ts';

const router = Router();

router.post('/', authenticate, registerForEvent);
router.get('/my', authenticate, getMyRegistrations);
router.get('/event/:eventId', authenticate, authorize('coordinator', 'admin'), getEventRegistrations);
router.patch('/:id/attendance', authenticate, authorize('coordinator', 'admin'), updateAttendance);
router.delete('/:id', authenticate, cancelRegistration);

export default router;
