import { Router } from 'express';
import {
  requestMembership,
  getMyMemberships,
  getClubMemberships,
  getAllMembershipsForCoordinator,
  updateMembershipStatus,
  deleteMembership,
} from '../controllers/membershipController.ts';
import { authenticate, authorize } from '../middleware/auth.ts';

const router = Router();

router.post('/', authenticate, requestMembership);
router.get('/my', authenticate, getMyMemberships);
router.get('/coordinator', authenticate, authorize('coordinator', 'admin'), getAllMembershipsForCoordinator);
router.get('/club/:clubId', authenticate, getClubMemberships);
router.patch('/:id/status', authenticate, authorize('coordinator', 'admin'), updateMembershipStatus);
router.delete('/:id', authenticate, deleteMembership);

export default router;
