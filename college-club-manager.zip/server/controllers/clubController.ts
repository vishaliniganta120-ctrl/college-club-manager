import { Request, Response } from 'express';
import { store } from '../services/dataStore.ts';
import { AuthenticatedRequest } from '../middleware/auth.ts';

export async function getClubs(req: Request, res: Response) {
  try {
    const clubs = store.getClubs();
    return res.json(clubs);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching clubs.' });
  }
}

export async function getClubById(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const club = store.getClubById(id);
    if (!club) {
      return res.status(404).json({ message: 'Club not found.' });
    }
    return res.json(club);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching club.' });
  }
}

export async function createClub(req: AuthenticatedRequest, res: Response) {
  try {
    const { name, description, category, logo, image, coordinator } = req.body;

    if (!name || !description || !category || !coordinator) {
      return res.status(400).json({
        message: 'Name, description, category, and assigned coordinator are required.',
      });
    }

    // Verify coordinator user exists
    const coordUser = store.getUserById(coordinator);
    if (!coordUser) {
      return res.status(400).json({ message: 'Selected coordinator does not exist.' });
    }

    const newClub = store.createClub({
      name: name.trim(),
      description: description.trim(),
      category,
      logo,
      image,
      coordinator,
    });

    return res.status(201).json({ message: 'Club created successfully.', club: newClub });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error creating club.' });
  }
}

export async function updateClub(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const existing = store.getClubById(id);
    if (!existing) {
      return res.status(404).json({ message: 'Club not found.' });
    }

    // Check authorization: Admin or assigned coordinator
    const isCoordinator =
      typeof existing.coordinator === 'object'
        ? (existing.coordinator as any)._id === req.user?._id
        : existing.coordinator === req.user?._id;

    if (req.user?.role !== 'admin' && !isCoordinator) {
      return res.status(403).json({
        message: 'Forbidden: You are not authorized to update this club.',
      });
    }

    const { name, description, category, logo, image, coordinator } = req.body;
    const updates: any = {};
    if (name) updates.name = name.trim();
    if (description) updates.description = description.trim();
    if (category) updates.category = category;
    if (logo !== undefined) updates.logo = logo;
    if (image !== undefined) updates.image = image;

    // Only admin can reassign coordinator
    if (coordinator && req.user?.role === 'admin') {
      const coordUser = store.getUserById(coordinator);
      if (!coordUser) {
        return res.status(400).json({ message: 'Assigned coordinator user does not exist.' });
      }
      updates.coordinator = coordinator;
    }

    const updated = store.updateClub(id, updates);
    return res.json({ message: 'Club updated successfully.', club: updated });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error updating club.' });
  }
}

export async function deleteClub(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const success = store.deleteClub(id);
    if (!success) {
      return res.status(404).json({ message: 'Club not found.' });
    }
    return res.json({ message: 'Club deleted successfully.' });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error deleting club.' });
  }
}
