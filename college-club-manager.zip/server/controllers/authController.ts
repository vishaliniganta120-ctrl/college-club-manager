import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { store } from '../services/dataStore.ts';
import { generateToken, AuthenticatedRequest } from '../middleware/auth.ts';

export async function register(req: Request, res: Response) {
  try {
    const { name, email, password, studentId, department, year, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email, and password are required.' });
    }

    // Check email uniqueness
    const existingEmail = store.getUserByEmail(email);
    if (existingEmail) {
      return res.status(400).json({ message: 'An account with this email already exists.' });
    }

    // Check studentId uniqueness if provided
    if (studentId) {
      const existingStudentId = store.getUserByStudentId(studentId);
      if (existingStudentId) {
        return res.status(400).json({ message: 'An account with this Student ID already exists.' });
      }
    }

    // Validate role requested; prevent non-authorized creation of admin directly via public register
    const assignedRole = role === 'coordinator' ? 'coordinator' : 'student';

    const newUser = store.createUser({
      name: name.trim(),
      email: email.trim(),
      password,
      studentId: studentId?.trim(),
      department: department?.trim(),
      year: year ? Number(year) : undefined,
      role: assignedRole,
    });

    const token = generateToken({
      _id: newUser._id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
      studentId: newUser.studentId,
      department: newUser.department,
      year: newUser.year,
    });

    const { passwordHash, ...safeUser } = newUser;
    return res.status(201).json({
      message: 'Registration successful.',
      token,
      user: safeUser,
    });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Internal server error during registration.' });
  }
}

export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required.' });
    }

    const user = store.getUserByEmail(email);
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials. User not found.' });
    }

    const isMatch = bcrypt.compareSync(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials. Password does not match.' });
    }

    const token = generateToken({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      studentId: user.studentId,
      department: user.department,
      year: user.year,
    });

    const { passwordHash, ...safeUser } = user;
    return res.json({
      message: 'Login successful.',
      token,
      user: safeUser,
    });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Internal server error during login.' });
  }
}

export async function getMe(req: AuthenticatedRequest, res: Response) {
  if (!req.user) {
    return res.status(401).json({ message: 'Not authenticated.' });
  }

  const user = store.getUserById(req.user._id);
  if (!user) {
    return res.status(404).json({ message: 'User record not found.' });
  }

  const { passwordHash, ...safeUser } = user;
  return res.json(safeUser);
}
