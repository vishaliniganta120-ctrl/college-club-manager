import { Request, Response } from 'express';
import { store } from '../services/dataStore.ts';
import { AuthenticatedRequest } from '../middleware/auth.ts';

export async function getEvents(req: Request, res: Response) {
  try {
    const events = store.getEvents();
    return res.json(events);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching events.' });
  }
}

export async function getEventById(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const event = store.getEventById(id);
    if (!event) {
      return res.status(404).json({ message: 'Event not found.' });
    }
    return res.json(event);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching event.' });
  }
}

export async function createEvent(req: AuthenticatedRequest, res: Response) {
  try {
    const { title, description, club, date, time, venue, capacity, image } = req.body;

    if (!title || !description || !club || !date || !time || !venue || !capacity) {
      return res.status(400).json({
        message: 'Title, description, club, date, time, venue, and capacity are required.',
      });
    }

    const clubRecord = store.getClubById(club);
    if (!clubRecord) {
      return res.status(400).json({ message: 'Associated club does not exist.' });
    }

    // Authorization check: Admin or coordinator of this club
    const isCoordinator =
      typeof clubRecord.coordinator === 'object'
        ? (clubRecord.coordinator as any)._id === req.user?._id
        : clubRecord.coordinator === req.user?._id;

    if (req.user?.role !== 'admin' && !isCoordinator) {
      return res.status(403).json({
        message: 'Forbidden: You are not authorized to create events for this club.',
      });
    }

    const newEvent = store.createEvent({
      title: title.trim(),
      description: description.trim(),
      club,
      date,
      time,
      venue: venue.trim(),
      capacity: Number(capacity),
      createdBy: req.user!._id,
      image,
    });

    return res.status(201).json({ message: 'Event created successfully.', event: newEvent });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error creating event.' });
  }
}

export async function updateEvent(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const existing = store.getEventById(id);
    if (!existing) {
      return res.status(404).json({ message: 'Event not found.' });
    }

    const clubId = typeof existing.club === 'object' ? (existing.club as any)._id : existing.club;
    const clubRecord = store.getClubById(clubId);

    const isCoordinator =
      clubRecord &&
      (typeof clubRecord.coordinator === 'object'
        ? (clubRecord.coordinator as any)._id === req.user?._id
        : clubRecord.coordinator === req.user?._id);

    if (req.user?.role !== 'admin' && !isCoordinator) {
      return res.status(403).json({
        message: 'Forbidden: You are not authorized to edit this event.',
      });
    }

    const { title, description, date, time, venue, capacity, image } = req.body;
    const updates: any = {};
    if (title) updates.title = title.trim();
    if (description) updates.description = description.trim();
    if (date) updates.date = date;
    if (time) updates.time = time;
    if (venue) updates.venue = venue.trim();
    if (capacity !== undefined) updates.capacity = Number(capacity);
    if (image !== undefined) updates.image = image;

    const updated = store.updateEvent(id, updates);
    return res.json({ message: 'Event updated successfully.', event: updated });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error updating event.' });
  }
}

export async function deleteEvent(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const existing = store.getEventById(id);
    if (!existing) {
      return res.status(404).json({ message: 'Event not found.' });
    }

    const clubId = typeof existing.club === 'object' ? (existing.club as any)._id : existing.club;
    const clubRecord = store.getClubById(clubId);

    const isCoordinator =
      clubRecord &&
      (typeof clubRecord.coordinator === 'object'
        ? (clubRecord.coordinator as any)._id === req.user?._id
        : clubRecord.coordinator === req.user?._id);

    if (req.user?.role !== 'admin' && !isCoordinator) {
      return res.status(403).json({
        message: 'Forbidden: You are not authorized to delete this event.',
      });
    }

    store.deleteEvent(id);
    return res.json({ message: 'Event deleted successfully.' });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error deleting event.' });
  }
}
