import { Response } from 'express';
import { store } from '../services/dataStore.ts';
import { AuthenticatedRequest } from '../middleware/auth.ts';

export async function requestMembership(req: AuthenticatedRequest, res: Response) {
  try {
    const userId = req.user?._id;
    if (!userId) {
      return res.status(401).json({ message: 'User not authenticated.' });
    }

    const { clubId } = req.body;
    if (!clubId) {
      return res.status(400).json({ message: 'clubId is required.' });
    }

    const club = store.getClubById(clubId);
    if (!club) {
      return res.status(404).json({ message: 'Club not found.' });
    }

    // Check duplicate constraint
    const existing = store.findActiveMembership(userId, clubId);
    if (existing) {
      if (existing.status === 'approved') {
        return res.status(400).json({ message: 'You are already an active member of this club.' });
      }
      if (existing.status === 'pending') {
        return res.status(400).json({
          message: 'You already have a pending membership request for this club.',
        });
      }
    }

    const membership = store.createMembership(userId, clubId);
    return res.status(201).json({
      message: 'Membership request submitted successfully. Awaiting coordinator review.',
      membership,
    });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error submitting membership request.' });
  }
}

export async function getMyMemberships(req: AuthenticatedRequest, res: Response) {
  try {
    const userId = req.user?._id;
    if (!userId) {
      return res.status(401).json({ message: 'User not authenticated.' });
    }

    const memberships = store.getMemberships({ userId });
    return res.json(memberships);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching memberships.' });
  }
}

export async function getClubMemberships(req: AuthenticatedRequest, res: Response) {
  try {
    const { clubId } = req.params;
    const status = req.query.status as string | undefined;

    const club = store.getClubById(clubId);
    if (!club) {
      return res.status(404).json({ message: 'Club not found.' });
    }

    // Authorization: Admin or coordinator of this club
    const isCoordinator =
      typeof club.coordinator === 'object'
        ? (club.coordinator as any)._id === req.user?._id
        : club.coordinator === req.user?._id;

    if (req.user?.role !== 'admin' && !isCoordinator) {
      return res.status(403).json({
        message: 'Forbidden: Only the club coordinator or an admin can view this club’s membership requests.',
      });
    }

    const memberships = store.getMemberships({ clubId, status });
    return res.json(memberships);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching club memberships.' });
  }
}

export async function getAllMembershipsForCoordinator(req: AuthenticatedRequest, res: Response) {
  try {
    // Returns all memberships across clubs for coordinators or admins
    const status = req.query.status as string | undefined;
    const clubId = req.query.clubId as string | undefined;
    const all = store.getMemberships({ clubId, status });

    if (req.user?.role === 'admin') {
      return res.json(all);
    }

    // Filter to clubs coordinated by this coordinator
    const userClubs = store
      .getClubs()
      .filter((c) => {
        const coordId = typeof c.coordinator === 'object' ? (c.coordinator as any)._id : c.coordinator;
        return coordId === req.user?._id;
      })
      .map((c) => c._id);

    const filtered = all.filter((m) => {
      const cId = typeof m.club === 'object' ? (m.club as any)._id : m.club;
      return userClubs.includes(cId);
    });

    return res.json(filtered);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching coordinator memberships.' });
  }
}

export async function updateMembershipStatus(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ message: "Status must be 'approved' or 'rejected'." });
    }

    const memberships = store.getMemberships();
    const target = memberships.find((m) => m._id === id);
    if (!target) {
      return res.status(404).json({ message: 'Membership record not found.' });
    }

    const clubId = typeof target.club === 'object' ? (target.club as any)._id : target.club;
    const club = store.getClubById(clubId);

    // Authorization: Admin or coordinator of this club
    const isCoordinator =
      club &&
      (typeof club.coordinator === 'object'
        ? (club.coordinator as any)._id === req.user?._id
        : club.coordinator === req.user?._id);

    if (req.user?.role !== 'admin' && !isCoordinator) {
      return res.status(403).json({
        message: 'Forbidden: You cannot review memberships for this club.',
      });
    }

    const updated = store.updateMembershipStatus(id, status);
    return res.json({
      message: `Membership status updated to ${status}.`,
      membership: updated,
    });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error updating membership status.' });
  }
}

export async function deleteMembership(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const memberships = store.getMemberships();
    const target = memberships.find((m) => m._id === id);
    if (!target) {
      return res.status(404).json({ message: 'Membership record not found.' });
    }

    const targetUserId = typeof target.user === 'object' ? (target.user as any)._id : target.user;
    const clubId = typeof target.club === 'object' ? (target.club as any)._id : target.club;
    const club = store.getClubById(clubId);

    const isCoordinator =
      club &&
      (typeof club.coordinator === 'object'
        ? (club.coordinator as any)._id === req.user?._id
        : club.coordinator === req.user?._id);

    // Can delete if user is the student themselves, the coordinator, or admin
    if (req.user?.role !== 'admin' && !isCoordinator && req.user?._id !== targetUserId) {
      return res.status(403).json({
        message: 'Forbidden: You are not authorized to cancel this membership.',
      });
    }

    store.deleteMembership(id);
    return res.json({ message: 'Membership removed / cancelled successfully.' });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error deleting membership.' });
  }
}
