import { Response } from 'express';
import bcrypt from 'bcryptjs';
import { store } from '../services/dataStore.ts';
import { AuthenticatedRequest } from '../middleware/auth.ts';

export async function getAllUsers(req: AuthenticatedRequest, res: Response) {
  try {
    const users = store.getUsers();
    return res.json(users);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching users.' });
  }
}

export async function getUserById(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const user = store.getUserById(id);
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }
    const { passwordHash, ...safeUser } = user;
    return res.json(safeUser);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching user.' });
  }
}

export async function updateUser(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const currentUserId = req.user?._id;
    const currentUserRole = req.user?.role;

    // Check authorization: must be admin or updating own account
    if (currentUserRole !== 'admin' && currentUserId !== id) {
      return res.status(403).json({ message: 'Forbidden: You can only update your own profile.' });
    }

    const { name, department, year, studentId, currentPassword, newPassword, role } = req.body;

    const user = store.getUserById(id);
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    // If changing password, verify current password (unless admin)
    if (newPassword) {
      if (currentUserRole !== 'admin') {
        if (!currentPassword) {
          return res.status(400).json({ message: 'Current password is required to set a new password.' });
        }
        const matches = bcrypt.compareSync(currentPassword, user.passwordHash);
        if (!matches) {
          return res.status(400).json({ message: 'Current password does not match.' });
        }
      }
    }

    // Role can only be changed by admin
    const updates: any = {};
    if (name) updates.name = name.trim();
    if (department !== undefined) updates.department = department?.trim();
    if (year !== undefined) updates.year = year ? Number(year) : undefined;
    if (studentId !== undefined) updates.studentId = studentId?.trim();
    if (newPassword) updates.newPassword = newPassword;
    if (currentUserRole === 'admin' && role) updates.role = role;

    const updated = store.updateUser(id, updates);
    if (!updated) {
      return res.status(404).json({ message: 'User could not be updated.' });
    }

    const { passwordHash, ...safeUser } = updated;
    return res.json({ message: 'Profile updated successfully.', user: safeUser });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error updating user.' });
  }
}

export async function deleteUser(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    if (req.user?._id === id) {
      return res.status(400).json({ message: 'Admins cannot delete their own active account.' });
    }

    const success = store.deleteUser(id);
    if (!success) {
      return res.status(404).json({ message: 'User not found.' });
    }

    return res.json({ message: 'User deleted successfully.' });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error deleting user.' });
  }
}
