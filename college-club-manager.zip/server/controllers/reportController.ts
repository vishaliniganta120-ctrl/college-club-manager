import { Request, Response } from 'express';
import { store } from '../services/dataStore.ts';
import { getDBStatus } from '../config/db.ts';

export async function getDashboardReport(req: Request, res: Response) {
  try {
    const stats = store.getDashboardStats();
    const dbStatus = getDBStatus();
    return res.json({
      ...stats,
      system: dbStatus,
    });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error generating dashboard report.' });
  }
}

export async function getParticipationReport(req: Request, res: Response) {
  try {
    const stats = store.getDashboardStats();
    const registrations = store.getRegistrations();
    const clubs = store.getClubs();
    const users = store.getUsers().filter((u) => u.role === 'student');

    // Attendance breakdown
    const attendanceSummary = {
      registered: registrations.filter((r) => r.attendanceStatus === 'registered').length,
      attended: registrations.filter((r) => r.attendanceStatus === 'attended').length,
      absent: registrations.filter((r) => r.attendanceStatus === 'absent').length,
      cancelled: registrations.filter((r) => r.status === 'cancelled').length,
    };

    // Category distribution
    const categoryDistribution: Record<string, number> = {};
    for (const club of clubs) {
      categoryDistribution[club.category] = (categoryDistribution[club.category] || 0) + (club.membersCount || 0);
    }

    return res.json({
      totalStudents: users.length,
      departmentParticipation: stats.departmentParticipation,
      popularClubs: stats.popularClubs,
      attendanceSummary,
      categoryDistribution: Object.entries(categoryDistribution).map(([category, count]) => ({
        category,
        members: count,
      })),
      eventsByMonth: stats.eventsByMonth,
    });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error generating participation report.' });
  }
}
