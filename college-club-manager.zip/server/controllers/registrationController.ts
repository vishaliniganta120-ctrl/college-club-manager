import { Response } from 'express';
import { store } from '../services/dataStore.ts';
import { AuthenticatedRequest } from '../middleware/auth.ts';

export async function registerForEvent(req: AuthenticatedRequest, res: Response) {
  try {
    const userId = req.user?._id;
    if (!userId) {
      return res.status(401).json({ message: 'User not authenticated.' });
    }

    const { eventId } = req.body;
    if (!eventId) {
      return res.status(400).json({ message: 'eventId is required.' });
    }

    const event = store.getEventById(eventId);
    if (!event) {
      return res.status(404).json({ message: 'Event not found.' });
    }

    // Check duplicate registration
    const existing = store.findExistingRegistration(userId, eventId);
    if (existing) {
      return res.status(400).json({ message: 'You have already registered for this event.' });
    }

    // Check capacity constraint on the server
    const currentConfirmed = store
      .getRegistrations({ eventId })
      .filter((r) => r.status === 'confirmed').length;

    if (currentConfirmed >= event.capacity) {
      return res.status(400).json({
        message: `Registration full: This event has reached its maximum capacity of ${event.capacity} seats.`,
      });
    }

    const registration = store.createRegistration(userId, eventId);
    return res.status(201).json({
      message: 'Successfully registered for event.',
      registration,
    });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error processing event registration.' });
  }
}

export async function getMyRegistrations(req: AuthenticatedRequest, res: Response) {
  try {
    const userId = req.user?._id;
    if (!userId) {
      return res.status(401).json({ message: 'User not authenticated.' });
    }

    const registrations = store.getRegistrations({ userId });
    return res.json(registrations);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching registrations.' });
  }
}

export async function getEventRegistrations(req: AuthenticatedRequest, res: Response) {
  try {
    const { eventId } = req.params;
    const event = store.getEventById(eventId);
    if (!event) {
      return res.status(404).json({ message: 'Event not found.' });
    }

    const clubId = typeof event.club === 'object' ? (event.club as any)._id : event.club;
    const club = store.getClubById(clubId);

    const isCoordinator =
      club &&
      (typeof club.coordinator === 'object'
        ? (club.coordinator as any)._id === req.user?._id
        : club.coordinator === req.user?._id);

    if (req.user?.role !== 'admin' && !isCoordinator) {
      return res.status(403).json({
        message: 'Forbidden: You cannot view registrations for this event.',
      });
    }

    const registrations = store.getRegistrations({ eventId });
    return res.json(registrations);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching event registrations.' });
  }
}

export async function updateAttendance(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const { attendanceStatus } = req.body;

    if (!['registered', 'attended', 'absent', 'cancelled'].includes(attendanceStatus)) {
      return res.status(400).json({
        message: "attendanceStatus must be 'registered', 'attended', 'absent', or 'cancelled'.",
      });
    }

    const registrations = store.getRegistrations();
    const reg = registrations.find((r) => r._id === id);
    if (!reg) {
      return res.status(404).json({ message: 'Registration record not found.' });
    }

    const eventId = typeof reg.event === 'object' ? (reg.event as any)._id : reg.event;
    const event = store.getEventById(eventId);
    const clubId = event && (typeof event.club === 'object' ? (event.club as any)._id : event.club);
    const club = clubId ? store.getClubById(clubId) : null;

    const isCoordinator =
      club &&
      (typeof club.coordinator === 'object'
        ? (club.coordinator as any)._id === req.user?._id
        : club.coordinator === req.user?._id);

    if (req.user?.role !== 'admin' && !isCoordinator) {
      return res.status(403).json({
        message: 'Forbidden: You are not authorized to update attendance.',
      });
    }

    const updated = store.updateAttendanceStatus(id, attendanceStatus);
    return res.json({ message: 'Attendance status updated successfully.', registration: updated });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error updating attendance.' });
  }
}

export async function cancelRegistration(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const registrations = store.getRegistrations();
    const reg = registrations.find((r) => r._id === id);
    if (!reg) {
      return res.status(404).json({ message: 'Registration not found.' });
    }

    const regUserId = typeof reg.user === 'object' ? (reg.user as any)._id : reg.user;

    // Allowed if own registration or admin
    if (req.user?.role !== 'admin' && req.user?._id !== regUserId) {
      return res.status(403).json({
        message: 'Forbidden: You can only cancel your own registration.',
      });
    }

    store.deleteRegistration(id);
    return res.json({ message: 'Event registration cancelled successfully.' });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error cancelling registration.' });
  }
}
