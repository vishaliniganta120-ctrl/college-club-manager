import { Request, Response } from 'express';
import { store } from '../services/dataStore.ts';
import { AuthenticatedRequest } from '../middleware/auth.ts';

export async function getAnnouncements(req: Request, res: Response) {
  try {
    const clubId = req.query.clubId as string | undefined;
    const announcements = store.getAnnouncements(clubId);
    return res.json(announcements);
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error fetching announcements.' });
  }
}

export async function createAnnouncement(req: AuthenticatedRequest, res: Response) {
  try {
    const { title, message, club, priority } = req.body;

    if (!title || !message) {
      return res.status(400).json({ message: 'Title and message are required.' });
    }

    // If club is specified, check coordinator rights unless admin
    if (club) {
      const clubRecord = store.getClubById(club);
      if (!clubRecord) {
        return res.status(400).json({ message: 'Specified club does not exist.' });
      }

      const isCoordinator =
        typeof clubRecord.coordinator === 'object'
          ? (clubRecord.coordinator as any)._id === req.user?._id
          : clubRecord.coordinator === req.user?._id;

      if (req.user?.role !== 'admin' && !isCoordinator) {
        return res.status(403).json({
          message: 'Forbidden: You can only publish announcements for your assigned club.',
        });
      }
    } else {
      // General announcement without club: admin only
      if (req.user?.role !== 'admin') {
        return res.status(403).json({
          message: 'Forbidden: Only administrators can publish campus-wide announcements.',
        });
      }
    }

    const newAnnouncement = store.createAnnouncement({
      title: title.trim(),
      message: message.trim(),
      club: club || undefined,
      priority: priority || 'normal',
      createdBy: req.user!._id,
    });

    return res.status(201).json({
      message: 'Announcement published successfully.',
      announcement: newAnnouncement,
    });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error publishing announcement.' });
  }
}

export async function updateAnnouncement(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const announcements = store.getAnnouncements();
    const existing = announcements.find((a) => a._id === id);
    if (!existing) {
      return res.status(404).json({ message: 'Announcement not found.' });
    }

    const creatorId =
      typeof existing.createdBy === 'object'
        ? (existing.createdBy as any)._id
        : existing.createdBy;

    if (req.user?.role !== 'admin' && req.user?._id !== creatorId) {
      return res.status(403).json({
        message: 'Forbidden: You are not authorized to edit this announcement.',
      });
    }

    const { title, message, priority } = req.body;
    const updates: any = {};
    if (title) updates.title = title.trim();
    if (message) updates.message = message.trim();
    if (priority) updates.priority = priority;

    const updated = store.updateAnnouncement(id, updates);
    return res.json({ message: 'Announcement updated.', announcement: updated });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error updating announcement.' });
  }
}

export async function deleteAnnouncement(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const announcements = store.getAnnouncements();
    const existing = announcements.find((a) => a._id === id);
    if (!existing) {
      return res.status(404).json({ message: 'Announcement not found.' });
    }

    const creatorId =
      typeof existing.createdBy === 'object'
        ? (existing.createdBy as any)._id
        : existing.createdBy;

    if (req.user?.role !== 'admin' && req.user?._id !== creatorId) {
      return res.status(403).json({
        message: 'Forbidden: You are not authorized to delete this announcement.',
      });
    }

    store.deleteAnnouncement(id);
    return res.json({ message: 'Announcement deleted successfully.' });
  } catch (err: any) {
    return res.status(500).json({ message: err.message || 'Error deleting announcement.' });
  }
}
