import React, { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  BarChart3,
  TrendingUp,
  PieChart as PieIcon,
  Users,
  CheckCircle,
  FileSpreadsheet,
  RefreshCw,
} from 'lucide-react';

const COLORS = ['#8B5CF6', '#6366F1', '#3B82F6', '#10B981', '#F59E0B', '#EC4899', '#14B8A6'];

export const ReportsPage: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await api.reports.getParticipation();
      setData(res);
    } catch (err) {
      console.error('Failed to load participation reports:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  if (loading || !data) {
    return (
      <div className="p-12 flex justify-center items-center">
        <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const {
    totalStudents,
    departmentParticipation,
    popularClubs,
    attendanceSummary,
    categoryDistribution,
    eventsByMonth,
  } = data;

  const attendanceChartData = [
    { name: 'Attended', value: attendanceSummary?.attended || 0, color: '#10B981' },
    { name: 'Registered (Upcoming)', value: attendanceSummary?.registered || 0, color: '#8B5CF6' },
    { name: 'Absent', value: attendanceSummary?.absent || 0, color: '#EF4444' },
    { name: 'Cancelled', value: attendanceSummary?.cancelled || 0, color: '#94A3B8' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Reports & Analytics</h1>
          <p className="text-xs text-slate-500 mt-1">
            Institutional metrics on student participation, club engagement, and event attendance.
          </p>
        </div>

        <button
          onClick={loadData}
          className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-xs flex items-center gap-2 self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
          <span>Refresh Analytics</span>
        </button>
      </div>

      {/* Top Highlights Summary Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl border border-slate-200 bg-white">
          <span className="text-xs font-medium text-slate-500">Total Enrolled Students</span>
          <div className="text-2xl font-extrabold text-slate-900 mt-1 tabular-nums">
            {totalStudents}
          </div>
          <span className="text-[11px] text-slate-400">Across 8 academic departments</span>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 bg-white">
          <span className="text-xs font-medium text-slate-500">Total Event Bookings</span>
          <div className="text-2xl font-extrabold text-slate-900 mt-1 tabular-nums">
            {(attendanceSummary?.attended || 0) + (attendanceSummary?.registered || 0)}
          </div>
          <span className="text-[11px] text-slate-400">Seat reservations recorded</span>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 bg-white">
          <span className="text-xs font-medium text-slate-500">Attended Participants</span>
          <div className="text-2xl font-extrabold text-emerald-600 mt-1 tabular-nums">
            {attendanceSummary?.attended || 0}
          </div>
          <span className="text-[11px] text-slate-400">Verified event attendances</span>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 bg-white">
          <span className="text-xs font-medium text-slate-500">Most Active Category</span>
          <div className="text-lg font-bold text-purple-700 mt-2 truncate">
            {categoryDistribution[0]?.category || 'Technology'}
          </div>
          <span className="text-[11px] text-slate-400">Highest member density</span>
        </div>
      </div>

      {/* Charts Row 1: Monthly Events & Attendance Status */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Events Schedule Breakdown */}
        <div className="lg:col-span-7 p-5 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Event Frequency Over Time</h2>
              <p className="text-[11px] text-slate-500">Workshops and competitive events per semester month</p>
            </div>
            <TrendingUp className="w-4 h-4 text-purple-600" />
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={eventsByMonth} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748B' }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748B' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1E293B',
                    color: '#fff',
                    borderRadius: '8px',
                    fontSize: '12px',
                    border: 'none',
                  }}
                />
                <Bar dataKey="events" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Attendance Breakdown Donut */}
        <div className="lg:col-span-5 p-5 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Attendance Status Breakdown</h2>
              <p className="text-[11px] text-slate-500">Attendee presence ratios</p>
            </div>
            <PieIcon className="w-4 h-4 text-purple-600" />
          </div>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={attendanceChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={3}
                  dataKey="value"
                  nameKey="name"
                >
                  {attendanceChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1E293B',
                    color: '#fff',
                    borderRadius: '8px',
                    fontSize: '12px',
                    border: 'none',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-slate-100">
            {attendanceChartData.map((item) => (
              <div key={item.name} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-slate-600">{item.name}:</span>
                <strong className="text-slate-900 tabular-nums">{item.value}</strong>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Charts Row 2: Department-Wise Participation & Category Density */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Department Participation */}
        <div className="lg:col-span-6 p-5 rounded-xl border border-slate-200 bg-white">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Department Participation Roster</h2>
          <p className="text-[11px] text-slate-500 mb-4">Undergraduate and graduate student dispersion</p>

          <div className="space-y-3">
            {departmentParticipation.map((dept: any, i: number) => {
              const maxCount = Math.max(...departmentParticipation.map((d: any) => d.count), 1);
              const pct = Math.round((dept.count / maxCount) * 100);

              return (
                <div key={dept.department} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-700">{dept.department}</span>
                    <span className="font-bold text-slate-900 tabular-nums">
                      {dept.count} students
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${pct}%`,
                        backgroundColor: COLORS[i % COLORS.length],
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Club Membership Distribution */}
        <div className="lg:col-span-6 p-5 rounded-xl border border-slate-200 bg-white">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Club Member Density</h2>
          <p className="text-[11px] text-slate-500 mb-4">Active members per student society</p>

          <div className="space-y-3">
            {popularClubs.map((club: any) => (
              <div
                key={club._id}
                className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-100"
              >
                <div>
                  <div className="text-xs font-bold text-slate-900">{club.name}</div>
                  <div className="text-[11px] text-slate-500">{club.category}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-extrabold text-purple-700 tabular-nums">
                    {club.membersCount}
                  </div>
                  <div className="text-[10px] text-slate-400">members</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
