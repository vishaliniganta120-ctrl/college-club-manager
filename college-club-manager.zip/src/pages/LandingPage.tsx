import React, { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import { Club, ClubEvent } from '../types/index.ts';
import {
  Compass,
  Calendar,
  Users,
  Award,
  ArrowRight,
  Sparkles,
  ChevronRight,
  Shield,
  MapPin,
  Phone,
  Mail,
  Clock,
  Music,
  Flame,
  Send,
  CheckCircle2,
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (page: string, params?: any) => void;
  onQuickLogin?: (role: 'student' | 'coordinator' | 'admin') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onNavigate,
  onQuickLogin,
}) => {
  const [clubs, setClubs] = useState<Club[]>([]);
  const [events, setEvents] = useState<ClubEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [contactSent, setContactSent] = useState(false);
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    phone: '',
    department: 'Computer Science & Engg',
    queryType: 'Dandiya Pass Registration',
    message: '',
  });

  useEffect(() => {
    async function fetchData() {
      try {
        const [c, e] = await Promise.all([api.clubs.getAll(), api.events.getAll()]);
        setClubs(c.slice(0, 4));
        setEvents(e);
      } catch (err) {
        console.warn('Error loading landing data:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSent(true);
    setTimeout(() => {
      setContactSent(false);
      setContactForm({
        name: '',
        email: '',
        phone: '',
        department: 'Computer Science & Engg',
        queryType: 'Dandiya Pass Registration',
        message: '',
      });
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-slate-50 selection:bg-amber-200 selection:text-amber-900">
      {/* Festive Banner Strip */}
      <div className="bg-gradient-to-r from-amber-600 via-rose-600 to-purple-800 text-white text-xs font-semibold py-2 px-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-900 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full shadow-xs">
              Upcoming Grand Fest
            </span>
            <span>
              MALLA REDDY VISHWAVIDHYAPEETH presents Saddula Bathukamma Mahotsavam (Oct 15) & Mega Dandiya Raas Night (Oct 18)!
            </span>
          </div>
          <button
            onClick={() => onNavigate('events')}
            className="text-amber-200 hover:text-white underline font-bold text-xs whitespace-nowrap"
          >
            Reserve Your Free Entry Pass →
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-amber-50/60 via-white to-slate-50 border-b border-amber-200/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Copy & Actions */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-100/80 text-amber-900 text-xs font-bold border border-amber-300/80 shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>MALLA REDDY VISHWAVIDHYAPEETH · CAMPUS CLUBS & FESTS</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-950 leading-[1.15]">
                Experience the Rhythms of <span className="bg-gradient-to-r from-amber-600 via-rose-600 to-purple-700 bg-clip-text text-transparent">Dandiya Raas</span> & <span className="text-amber-700">Bathukamma Mahotsav</span> 2026.
              </h1>

              <p className="text-sm sm:text-base text-slate-700 max-w-2xl leading-relaxed">
                Welcome to <strong>MALLA REDDY VISHWAVIDHYAPEETH</strong>'s centralized student club and festive events hub.
                Connect with 8+ student societies, join the grand Navratri Dandiya dance floor, compete in traditional floral Bathukamma contests, and lead campus life!
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => onNavigate('events')}
                  className="px-6 py-3 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-amber-500 via-rose-600 to-purple-600 hover:from-amber-600 hover:to-purple-700 shadow-md shadow-rose-500/20 transition-all flex items-center gap-2 whitespace-nowrap"
                >
                  <span>🪔 Register for Dandiya & Bathukamma</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onNavigate('explore')}
                  className="px-6 py-3 rounded-xl text-sm font-semibold text-slate-800 hover:text-slate-950 bg-white border border-slate-300 hover:bg-slate-50 transition-colors whitespace-nowrap shadow-xs"
                >
                  Explore All MRV Clubs
                </button>
              </div>

              {/* Quick Login Demonstration bar for evaluators */}
              {onQuickLogin && (
                <div className="pt-4 border-t border-slate-200">
                  <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    1-Click Hackathon Evaluator Login:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => onQuickLogin('student')}
                      className="px-3 py-1.5 text-xs font-semibold bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-lg transition-colors shadow-xs"
                    >
                      Login as Student (Sai Teja)
                    </button>
                    <button
                      onClick={() => onQuickLogin('coordinator')}
                      className="px-3 py-1.5 text-xs font-semibold bg-white hover:bg-purple-100 text-purple-900 border border-purple-300 rounded-lg transition-colors shadow-xs"
                    >
                      Login as Coordinator (Dr. Sunitha)
                    </button>
                    <button
                      onClick={() => onQuickLogin('admin')}
                      className="px-3 py-1.5 text-xs font-semibold bg-white hover:bg-rose-100 text-rose-900 border border-rose-300 rounded-lg transition-colors shadow-xs"
                    >
                      Login as Admin (Registrar Office)
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Right Column: Hero Visual Highlight */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-2 border-amber-300/80 aspect-[16/10] bg-slate-100 ring-4 ring-amber-100">
                <img
                  src="/src/assets/images/dandiya_night_festival_1791571677852.jpg"
                  alt="Dandiya Raas celebration night at Malla Reddy Vishwavidyapeeth"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent flex items-end p-6">
                  <div className="text-white space-y-1">
                    <div className="inline-block text-[10px] font-bold bg-amber-500 text-slate-950 px-2 py-0.5 rounded shadow-xs uppercase">
                      Grand Flagship Event
                    </div>
                    <div className="text-lg font-extrabold leading-tight">
                      Mega Dandiya & Garba Raas Night 2026
                    </div>
                    <div className="text-xs text-amber-200">
                      University Cricket Grounds · October 18 · 6:00 PM Onwards
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Flagship Fest Spotlight: Dandiya Night & Bathukamma Mahotsav */}
      <section id="fest" className="py-16 bg-gradient-to-b from-white via-amber-50/40 to-white border-b border-amber-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center max-w-3xl mx-auto space-y-2">
            <span className="text-xs font-bold text-rose-700 uppercase tracking-widest bg-rose-50 border border-rose-200 px-3 py-1 rounded-full">
              University Cultural Fest Special
            </span>
            <h2 className="text-3xl font-extrabold text-slate-950 tracking-tight">
              Grand Festivities at Malla Reddy Vishwavidyapeeth
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              Immerse in the colorful folk traditions of Telangana's floral Bathukamma and the energetic rhythms of Navratri Dandiya Raas with thousands of fellow students.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Card 1: Mega Dandiya Night */}
            <div className="bg-white rounded-2xl border-2 border-amber-300 shadow-lg overflow-hidden flex flex-col justify-between hover:shadow-xl transition-all">
              <div className="relative h-64 bg-slate-900">
                <img
                  src="/src/assets/images/dandiya_night_festival_1791571677852.jpg"
                  alt="Dandiya Raas Night"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 bg-gradient-to-r from-amber-500 to-rose-600 text-white text-[11px] font-bold px-3 py-1 rounded-md shadow-md uppercase tracking-wide">
                  ⭐ Featured Event · 18 Oct 2026
                </div>
                <div className="absolute bottom-3 right-3 bg-black/75 backdrop-blur-xs text-white text-xs font-semibold px-2.5 py-1 rounded-md">
                  Capacity: 600 Attendees
                </div>
              </div>

              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs text-rose-700 font-bold mb-1">
                    <Music className="w-4 h-4" />
                    <span>Cultural Club & Student Affairs Presents</span>
                  </div>
                  <h3 className="text-xl font-black text-slate-950 mb-2">
                    Malla Reddy Vishwavidyapeeth Mega Dandiya & Garba Raas Night
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Get ready for the most awaited cultural spectacle! Live Punjabi & Gujarati Dhol artists, non-stop Bollywood & Garba beats by celebrity DJ, decorative Dandiya sticks provided upon entry, and mouth-watering festive food stalls.
                  </p>

                  <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-100 text-xs">
                    <div className="p-2.5 rounded-lg bg-amber-50/70 border border-amber-200">
                      <span className="block text-[10px] text-amber-800 font-bold uppercase">Competitions</span>
                      <strong className="text-slate-900 text-[11px]">Best Dandiya Dancer & Best Traditional Attire</strong>
                    </div>
                    <div className="p-2.5 rounded-lg bg-rose-50/70 border border-rose-200">
                      <span className="block text-[10px] text-rose-800 font-bold uppercase">Dress Code</span>
                      <strong className="text-slate-900 text-[11px]">Chaniya Choli / Kurta Pajama Mandatory</strong>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div className="text-xs text-slate-500">
                    Venue: <strong>Central Cricket Lawns</strong>
                  </div>
                  <button
                    onClick={() => onNavigate('events')}
                    className="px-5 py-2 text-xs font-bold text-white bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-600 hover:to-rose-700 rounded-lg shadow-sm"
                  >
                    Reserve Dandiya Pass
                  </button>
                </div>
              </div>
            </div>

            {/* Card 2: Saddula Bathukamma Mahotsavam */}
            <div className="bg-white rounded-2xl border-2 border-emerald-300 shadow-lg overflow-hidden flex flex-col justify-between hover:shadow-xl transition-all">
              <div className="relative h-64 bg-slate-900">
                <img
                  src="/src/assets/images/bathukamma_celebration_mrv_1791571690625.jpg"
                  alt="Bathukamma Celebration at Malla Reddy Vishwavidyapeeth"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white text-[11px] font-bold px-3 py-1 rounded-md shadow-md uppercase tracking-wide">
                  🌸 Telangana Pride · 15 Oct 2026
                </div>
                <div className="absolute bottom-3 right-3 bg-black/75 backdrop-blur-xs text-white text-xs font-semibold px-2.5 py-1 rounded-md">
                  Capacity: 450 Attendees
                </div>
              </div>

              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs text-emerald-800 font-bold mb-1">
                    <Sparkles className="w-4 h-4" />
                    <span>Cultural Affairs & Telangana Heritage Forum</span>
                  </div>
                  <h3 className="text-xl font-black text-slate-950 mb-2">
                    Saddula Bathukamma Mahotsavam & Floral Pyramid Challenge
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Celebrate the sacred festival of flowers with rhythmic folk songs, graceful clapping dances, and majestic floral towers crafted with Gunugu, Thangedu, and Banthi flowers. Concludes with Maha Aarti and ceremonial nimajjanam.
                  </p>

                  <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-100 text-xs">
                    <div className="p-2.5 rounded-lg bg-emerald-50/70 border border-emerald-200">
                      <span className="block text-[10px] text-emerald-800 font-bold uppercase">Inter-Departmental Trophy</span>
                      <strong className="text-slate-900 text-[11px]">Best Floral Bathukamma (₹25,000 Cash Pool)</strong>
                    </div>
                    <div className="p-2.5 rounded-lg bg-amber-50/70 border border-amber-200">
                      <span className="block text-[10px] text-amber-800 font-bold uppercase">Performances</span>
                      <strong className="text-slate-900 text-[11px]">Potharaju Dance & Folk Troupe Singing</strong>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div className="text-xs text-slate-500">
                    Venue: <strong>Central Courtyard & Lawn</strong>
                  </div>
                  <button
                    onClick={() => onNavigate('events')}
                    className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm"
                  >
                    View Bathukamma Schedule
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Clubs Spotlight */}
      <section className="py-16 bg-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                MALLA REDDY VISHWAVIDHYAPEETH Clubs
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Explore engineering societies, cultural troupes, photography squads, and athletics leagues.
              </p>
            </div>
            <button
              onClick={() => onNavigate('explore')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-800 hover:text-amber-900"
            >
              <span>Explore all clubs & societies</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {clubs.map((club) => (
              <div
                key={club._id}
                className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:border-amber-300 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div className="h-40 bg-slate-100 relative">
                  {club.image ? (
                    <img
                      src={club.image}
                      alt={club.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-amber-50 text-amber-700">
                      <Compass className="w-12 h-12 stroke-1" />
                    </div>
                  )}
                  <div className="absolute top-3 left-3 bg-white/95 text-slate-900 text-[10px] font-bold px-2 py-0.5 rounded shadow-xs">
                    {club.category}
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 mb-1">{club.name}</h3>
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-3">
                      {club.description}
                    </p>
                  </div>
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-500 text-[11px]">{club.membersCount || 0} members</span>
                    <button
                      onClick={() => onNavigate('club-detail', { clubId: club._id })}
                      className="text-xs font-bold text-amber-800 hover:text-amber-900"
                    >
                      View Club →
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* College Contact & Campus Location Section */}
      <section id="contact" className="py-16 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold text-purple-700 uppercase tracking-widest bg-purple-50 border border-purple-200 px-3 py-1 rounded-full">
              University Helpdesk & Directory
            </span>
            <h2 className="text-3xl font-extrabold text-slate-950 tracking-tight">
              Contact MALLA REDDY VISHWAVIDHYAPEETH
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              Have questions about club memberships, Dandiya passes, or campus facilities? Reach out to our campus offices.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column: Official Contact Cards */}
            <div className="lg:col-span-6 space-y-4">
              <div className="p-5 rounded-xl border border-slate-200 bg-amber-50/30 flex items-start gap-4">
                <div className="p-2.5 rounded-lg bg-amber-500 text-white shrink-0 mt-1 shadow-xs">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Campus Address</h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    <strong>MALLA REDDY VISHWAVIDHYAPEETH</strong><br />
                    Maisammaguda, Dhulapally, Post via Kompally,<br />
                    Secunderabad, Telangana 500100, India
                  </p>
                  <span className="text-[11px] text-amber-800 font-semibold block mt-1">
                    Landmark: Near Kompally Junction, Outer Ring Road Exit
                  </span>
                </div>
              </div>

              <div className="p-5 rounded-xl border border-slate-200 bg-rose-50/30 flex items-start gap-4">
                <div className="p-2.5 rounded-lg bg-rose-600 text-white shrink-0 mt-1 shadow-xs">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Phone Numbers & Helpdesks</h3>
                  <div className="text-xs text-slate-600 mt-1 space-y-0.5">
                    <div>Student Affairs & Fest Office: <strong>+91 40 2379 2146</strong></div>
                    <div>Dandiya & Bathukamma Hotline: <strong>+91 93481 61125</strong> / <strong>+91 93481 61126</strong></div>
                    <div>General Campus Reception: <strong>+91 40 2379 2100</strong></div>
                  </div>
                </div>
              </div>

              <div className="p-5 rounded-xl border border-slate-200 bg-purple-50/30 flex items-start gap-4">
                <div className="p-2.5 rounded-lg bg-purple-700 text-white shrink-0 mt-1 shadow-xs">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Official Email Addresses</h3>
                  <div className="text-xs text-slate-600 mt-1 space-y-0.5">
                    <div>Cultural Committee: <strong className="text-purple-700">cultural@mrv.ac.in</strong></div>
                    <div>General Information: <strong className="text-purple-700">info@mrv.ac.in</strong></div>
                    <div>Student Council: <strong className="text-purple-700">studentaffairs@mrv.ac.in</strong></div>
                  </div>
                </div>
              </div>

              <div className="p-5 rounded-xl border border-slate-200 bg-slate-50 flex items-start gap-4">
                <div className="p-2.5 rounded-lg bg-slate-800 text-white shrink-0 mt-1 shadow-xs">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Campus & Fest Timings</h3>
                  <div className="text-xs text-slate-600 mt-1">
                    <div>Regular Academic Timings: <strong>Mon – Sat, 9:00 AM – 4:30 PM</strong></div>
                    <div>Dandiya Raas Night Gates: <strong>5:30 PM Onwards (October 18)</strong></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Interactive Fest Inquiry Form */}
            <div className="lg:col-span-6 bg-slate-50 p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm">
              <h3 className="text-base font-bold text-slate-900 mb-1">
                Student & Fest Inquiry Desk
              </h3>
              <p className="text-xs text-slate-500 mb-6">
                Send a message to the Malla Reddy Vishwavidyapeeth Cultural & Student Affairs Committee.
              </p>

              {contactSent ? (
                <div className="p-6 rounded-xl bg-emerald-50 border border-emerald-200 text-center space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                  <h4 className="text-sm font-bold text-emerald-900">Inquiry Received!</h4>
                  <p className="text-xs text-emerald-700">
                    Thank you. The student affairs coordinator at Malla Reddy Vishwavidyapeeth will respond via email/SMS shortly.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Your Name</label>
                      <input
                        type="text"
                        required
                        value={contactForm.name}
                        onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                        placeholder="e.g. Sai Teja"
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">College Email</label>
                      <input
                        type="email"
                        required
                        value={contactForm.email}
                        onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                        placeholder="student@mrv.ac.in"
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Phone</label>
                      <input
                        type="tel"
                        required
                        value={contactForm.phone}
                        onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                        placeholder="+91 98765 43210"
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Inquiry Purpose</label>
                      <select
                        value={contactForm.queryType}
                        onChange={(e) => setContactForm({ ...contactForm, queryType: e.target.value })}
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                      >
                        <option value="Dandiya Pass Registration">Dandiya Pass & Stick Collection</option>
                        <option value="Bathukamma Competition Entry">Bathukamma Competition Entry</option>
                        <option value="Club Membership Help">Club Membership Guidance</option>
                        <option value="General Campus Question">General Campus Query</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Message</label>
                    <textarea
                      rows={3}
                      required
                      value={contactForm.message}
                      onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                      placeholder="Write your question or request..."
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-amber-500 via-rose-600 to-purple-600 hover:from-amber-600 hover:to-purple-700 shadow-sm flex items-center justify-center gap-2 transition-all"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Inquiry to MRV Helpdesk</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-slate-950 text-slate-400 text-xs border-t border-amber-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-800">
            <div>
              <div className="text-white font-black text-base tracking-wide flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-amber-500 inline-block"></span>
                <span>MALLA REDDY VISHWAVIDHYAPEETH</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Centralized Student Club & Festival Management Portal · Maisammaguda, Secunderabad, Telangana
              </p>
            </div>

            <div className="flex items-center gap-6">
              <button onClick={() => onNavigate('explore')} className="hover:text-amber-300 transition-colors">
                Explore Clubs
              </button>
              <button onClick={() => onNavigate('events')} className="hover:text-amber-300 transition-colors">
                Dandiya & Events
              </button>
              <button onClick={() => onNavigate('login')} className="hover:text-amber-300 transition-colors">
                Student Sign In
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
            <div>
              © 2026 MALLA REDDY VISHWAVIDHYAPEETH. All rights reserved.
            </div>
            <div>
              Student Affairs & Cultural Coordination Committee · Maisammaguda
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
