import React, { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import { Membership, Club, EventRegistration } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Users,
  Compass,
  Calendar,
  Clock,
  ArrowRight,
  LogOut,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { EmptyState } from '../components/common/EmptyState.tsx';

interface MyClubsPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const MyClubsPage: React.FC<MyClubsPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [coordinatedClubs, setCoordinatedClubs] = useState<Club[]>([]);
  const [registrations, setRegistrations] = useState<EventRegistration[]>([]);
  const [loading, setLoading] = useState(true);
  const [notification, setNotification] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      if (user?.role === 'coordinator') {
        const clubs = await api.clubs.getAll();
        const mine = clubs.filter((c) => {
          const coordId = typeof c.coordinator === 'object' ? (c.coordinator as any)._id : c.coordinator;
          return coordId === user._id;
        });
        setCoordinatedClubs(mine);
      }

      const [mems, regs] = await Promise.all([
        api.memberships.getMy(),
        api.registrations.getMy(),
      ]);
      setMemberships(mems);
      setRegistrations(regs);
    } catch (err: any) {
      console.error('Failed to load My Clubs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const handleLeave = async (membershipId: string) => {
    try {
      await api.memberships.delete(membershipId);
      setNotification('You have left the club.');
      await loadData();
    } catch (err: any) {
      console.error('Failed to leave club:', err);
    }
  };

  if (loading) {
    return (
      <div className="p-12 flex justify-center items-center">
        <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const approvedMemberships = memberships.filter((m) => m.status === 'approved');
  const pendingMemberships = memberships.filter((m) => m.status === 'pending');

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          {user?.role === 'coordinator' ? 'My Coordinated Clubs' : 'My Clubs & Memberships'}
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          {user?.role === 'coordinator'
            ? 'Manage the collegiate organizations assigned under your faculty coordination.'
            : 'Track the clubs you are part of and follow active membership requests.'}
        </p>
      </div>

      {notification && (
        <div className="p-3.5 rounded-lg text-xs flex items-center justify-between border bg-slate-100 border-slate-200 text-slate-800">
          <span>{notification}</span>
          <button onClick={() => setNotification(null)} className="font-bold">
            ✕
          </button>
        </div>
      )}

      {/* For Coordinator: Show Coordinated Clubs */}
      {user?.role === 'coordinator' && (
        <div className="space-y-4">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-slate-500">
            Assigned Leadership Clubs ({coordinatedClubs.length})
          </h2>

          {coordinatedClubs.length === 0 ? (
            <EmptyState
              icon={Compass}
              title="No clubs assigned"
              description="An administrator has not assigned any clubs to your coordinator profile yet."
            />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {coordinatedClubs.map((club) => (
                <div
                  key={club._id}
                  className="p-5 rounded-xl border border-slate-200 bg-white hover:border-purple-200 transition-colors flex flex-col justify-between"
                >
                  <div>
                    <div className="text-[11px] font-semibold text-purple-700 uppercase mb-1">
                      {club.category}
                    </div>
                    <h3 className="text-base font-bold text-slate-900 mb-2">{club.name}</h3>
                    <p className="text-xs text-slate-600 line-clamp-2 mb-4 leading-relaxed">
                      {club.description}
                    </p>
                    <div className="text-xs text-slate-500 mb-4">
                      Active Members: <strong className="text-slate-800">{club.membersCount || 0}</strong>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                    <button
                      onClick={() => onNavigate('club-detail', { clubId: club._id })}
                      className="flex-1 py-1.5 px-3 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg text-center"
                    >
                      Club Hub
                    </button>
                    <button
                      onClick={() => onNavigate('membership-requests')}
                      className="flex-1 py-1.5 px-3 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg text-center"
                    >
                      Review Members
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Student: Active Memberships */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-slate-500">
          Active Club Memberships ({approvedMemberships.length})
        </h2>

        {approvedMemberships.length === 0 ? (
          <EmptyState
            icon={Compass}
            title="You haven't joined any clubs yet"
            description="Explore our student societies and request to join the ones that match your passions."
            actionLabel="Discover Clubs"
            onAction={() => onNavigate('explore')}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {approvedMemberships.map((m) => {
              const club = typeof m.club === 'object' ? (m.club as any) : null;
              return (
                <div
                  key={m._id}
                  className="p-5 rounded-xl border border-slate-200 bg-white hover:border-purple-200 transition-colors flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="font-semibold text-purple-700">{club?.category}</span>
                      <span className="text-slate-400">
                        Joined {new Date(m.joinedAt).toLocaleDateString()}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-slate-900 mb-2">{club?.name}</h3>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                    <button
                      onClick={() => onNavigate('club-detail', { clubId: club?._id })}
                      className="text-xs font-semibold text-purple-600 hover:text-purple-700 flex items-center gap-1"
                    >
                      <span>Visit Club</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleLeave(m._id)}
                      className="text-xs text-rose-600 hover:text-rose-700 font-medium"
                    >
                      Leave
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Pending Membership Requests */}
      {pendingMemberships.length > 0 && (
        <div className="space-y-4 pt-4 border-t border-slate-200">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-slate-500">
            Pending Membership Requests ({pendingMemberships.length})
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {pendingMemberships.map((m) => {
              const club = typeof m.club === 'object' ? (m.club as any) : null;
              return (
                <div
                  key={m._id}
                  className="p-4 rounded-xl border border-amber-200 bg-amber-50/40 flex items-center justify-between"
                >
                  <div>
                    <div className="text-xs font-bold text-slate-900">{club?.name}</div>
                    <div className="text-[11px] text-amber-700 mt-0.5">
                      Submitted on {new Date(m.joinedAt).toLocaleDateString()} · In Review
                    </div>
                  </div>
                  <button
                    onClick={() => handleLeave(m._id)}
                    className="text-xs text-slate-500 hover:text-rose-600"
                    title="Cancel request"
                  >
                    Cancel
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Registered Events Ticker */}
      <div className="space-y-4 pt-4 border-t border-slate-200">
        <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-slate-500">
          My Registered Events ({registrations.filter((r) => r.status === 'confirmed').length})
        </h2>

        {registrations.filter((r) => r.status === 'confirmed').length === 0 ? (
          <div className="p-6 rounded-xl border border-slate-200 bg-white text-center text-xs text-slate-500">
            You haven't reserved tickets for any upcoming events yet.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {registrations
              .filter((r) => r.status === 'confirmed')
              .map((r) => {
                const evt = typeof r.event === 'object' ? (r.event as any) : null;
                return (
                  <div
                    key={r._id}
                    className="p-4 rounded-xl border border-slate-200 bg-white space-y-2"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-purple-700">{evt?.date}</span>
                      <span className="capitalize text-slate-500">{r.attendanceStatus}</span>
                    </div>
                    <div className="text-xs font-bold text-slate-900">{evt?.title}</div>
                    <div className="text-[11px] text-slate-500">{evt?.venue}</div>
                  </div>
                );
              })}
          </div>
        )}
      </div>
    </div>
  );
};
