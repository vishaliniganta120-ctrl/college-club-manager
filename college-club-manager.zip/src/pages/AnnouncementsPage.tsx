import React, { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import { Announcement, Club } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Megaphone,
  Plus,
  Search,
  CheckCircle2,
  AlertCircle,
  Clock,
  Trash2,
} from 'lucide-react';
import { Modal } from '../components/common/Modal.tsx';
import { EmptyState } from '../components/common/EmptyState.tsx';

export const AnnouncementsPage: React.FC = () => {
  const { user } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [clubs, setClubs] = useState<Club[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [notification, setNotification] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const [form, setForm] = useState({
    title: '',
    message: '',
    club: '',
    priority: 'normal' as 'normal' | 'important' | 'urgent',
  });

  const loadData = async () => {
    try {
      setLoading(true);
      const [annsRes, clubsRes] = await Promise.all([
        api.announcements.getAll(),
        api.clubs.getAll(),
      ]);
      setAnnouncements(annsRes);
      setClubs(clubsRes);
    } catch (err: any) {
      console.error('Failed to load announcements:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.announcements.create({
        title: form.title,
        message: form.message,
        club: form.club || undefined,
        priority: form.priority,
      });
      setIsModalOpen(false);
      setNotification({ text: 'Announcement broadcasted successfully!', type: 'success' });
      setForm({ title: '', message: '', club: '', priority: 'normal' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to publish announcement', type: 'error' });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.announcements.delete(id);
      setNotification({ text: 'Announcement deleted.', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to delete announcement', type: 'error' });
    }
  };

  const isPublisher = user?.role === 'admin' || user?.role === 'coordinator';

  const filtered = announcements.filter((a) => {
    const q = searchQuery.toLowerCase();
    const matchTitle = a.title.toLowerCase().includes(q);
    const matchMsg = a.message.toLowerCase().includes(q);
    return matchTitle || matchMsg;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Campus Announcements</h1>
          <p className="text-xs text-slate-500 mt-1">
            Official bulletins, recruitment schedules, and club news broadcasts.
          </p>
        </div>

        {isPublisher && (
          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg shadow-xs transition-colors flex items-center gap-2 whitespace-nowrap self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Publish Notice</span>
          </button>
        )}
      </div>

      {notification && (
        <div
          className={`p-3.5 rounded-lg text-xs flex items-center justify-between border ${
            notification.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600" />
            )}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="font-bold">
            ✕
          </button>
        </div>
      )}

      {/* Search Bar */}
      <div className="p-4 rounded-xl border border-slate-200 bg-white">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search bulletins and announcements..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      {/* Announcements List */}
      {loading ? (
        <div className="p-12 flex justify-center items-center">
          <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Megaphone}
          title="No announcements found"
          description="There are currently no active announcements matching your query."
        />
      ) : (
        <div className="space-y-4">
          {filtered.map((ann) => {
            const author = typeof ann.createdBy === 'object' ? (ann.createdBy as any).name : 'Faculty Staff';
            const clubName = typeof ann.club === 'object' && ann.club?.name ? ann.club.name : 'University-Wide Announcement';
            const canDelete =
              user?.role === 'admin' ||
              (typeof ann.createdBy === 'object'
                ? (ann.createdBy as any)._id === user?._id
                : ann.createdBy === user?._id);

            return (
              <div
                key={ann._id}
                className="p-5 rounded-xl border border-slate-200 bg-white shadow-xs space-y-3 hover:border-purple-200 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        ann.priority === 'urgent'
                          ? 'bg-rose-100 text-rose-800'
                          : ann.priority === 'important'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-purple-100 text-purple-800'
                      }`}
                    >
                      {ann.priority || 'Normal'}
                    </span>
                    <span className="text-xs font-semibold text-slate-800">{clubName}</span>
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-slate-400">
                    <span>
                      Posted by <strong>{author}</strong>
                    </span>
                    <span>·</span>
                    <span>{new Date(ann.createdAt).toLocaleDateString()}</span>
                    {canDelete && (
                      <button
                        onClick={() => handleDelete(ann._id)}
                        className="text-slate-400 hover:text-rose-600 ml-2"
                        title="Delete announcement"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-slate-900 mb-1">{ann.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line">
                    {ann.message}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal: Create Announcement */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Publish Official Notice"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Headline</label>
            <input
              type="text"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="e.g. Audition Dates for Autumn Play"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Target Audience / Club</label>
            <select
              value={form.club}
              onChange={(e) => setForm({ ...form, club: e.target.value })}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500 bg-white"
            >
              {user?.role === 'admin' && (
                <option value="">Campus-Wide Broadcast (All Students)</option>
              )}
              {clubs.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.name} ({c.category})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Priority</label>
            <select
              value={form.priority}
              onChange={(e) => setForm({ ...form, priority: e.target.value as any })}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="normal">Normal</option>
              <option value="important">Important (Highlighted)</option>
              <option value="urgent">Urgent Action Required</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Message Body</label>
            <textarea
              required
              rows={4}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Full announcement message..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg"
            >
              Publish
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
