import React, { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import { DashboardReport } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Compass,
  Users,
  Calendar,
  Ticket,
  Clock,
  ArrowRight,
  TrendingUp,
  Megaphone,
  Database,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

interface DashboardPageProps {
  onNavigate: (page: string, params?: any) => void;
}

const COLORS = ['#8B5CF6', '#6366F1', '#3B82F6', '#EC4899', '#10B981', '#F59E0B'];

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [data, setData] = useState<DashboardReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = async () => {
    try {
      setRefreshing(true);
      const res = await api.reports.getDashboard();
      setData(res);
    } catch (err) {
      console.error('Failed to load dashboard:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  if (loading || !data) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs text-slate-500 font-medium">Loading live campus analytics...</p>
        </div>
      </div>
    );
  }

  const { summary, upcomingEvents, recentAnnouncements, departmentParticipation, popularClubs, eventsByMonth, system } = data;

  return (
    <div className="space-y-8">
      {/* Top Welcome Strip & DB Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-amber-200">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-bold text-amber-800 bg-amber-100/90 px-2 py-0.5 rounded-full border border-amber-200 uppercase tracking-wide">
              MALLA REDDY VISHWAVIDHYAPEETH
            </span>
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">
            Welcome, {user?.name}
          </h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Campus Club Manager & Official Cultural Festival Portal · Secunderabad, Telangana
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Database mode indicator */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100 border border-slate-200 text-[11px] text-slate-600">
            <Database className="w-3.5 h-3.5 text-amber-600" />
            <span>DB: <strong className="font-semibold text-slate-800">{system?.mode || 'Active'}</strong></span>
          </div>

          <button
            onClick={loadData}
            disabled={refreshing}
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            title="Refresh statistics"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Special Festive Dandiya & Bathukamma Dashboard Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-600 to-purple-700 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[11px] font-bold backdrop-blur-xs">
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>UPCOMING FESTIVAL SPOTLIGHT · MRV 2026</span>
            </div>
            <h2 className="text-xl font-black">
              Saddula Bathukamma (Oct 15) & Mega Dandiya Raas Night (Oct 18)
            </h2>
            <p className="text-xs text-amber-100 leading-relaxed">
              Don't miss the high-energy Dhol beats, Garba circles, free Dandiya sticks, and floral pyramid trophies. Reserve your attendee pass or join the cultural club team now!
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onNavigate('events')}
              className="px-4 py-2 text-xs font-bold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded-xl shadow-xs transition-colors whitespace-nowrap"
            >
              Get Free Dandiya Pass →
            </button>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Total Clubs */}
        <div className="p-4 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Total Clubs</span>
            <div className="p-1.5 rounded-lg bg-purple-50 text-purple-600">
              <Compass className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-900 tabular-nums">
            {summary.totalClubs}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Active registered societies</div>
        </div>

        {/* Registered Students */}
        <div className="p-4 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Students</span>
            <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-900 tabular-nums">
            {summary.totalStudents}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Enrolled participants</div>
        </div>

        {/* Upcoming Events */}
        <div className="p-4 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Upcoming Events</span>
            <div className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-900 tabular-nums">
            {summary.upcomingEventsCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Scheduled campus activities</div>
        </div>

        {/* Event Registrations */}
        <div className="p-4 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Event Registrations</span>
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
              <Ticket className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-900 tabular-nums">
            {summary.totalRegistrations}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Confirmed attendee bookings</div>
        </div>

        {/* Pending Requests */}
        <div className="p-4 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Pending Requests</span>
            <div className="p-1.5 rounded-lg bg-amber-50 text-amber-600">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-900 tabular-nums">
            {summary.pendingMemberships}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Awaiting coordinator review</div>
        </div>
      </div>

      {/* Visual Analytics Grid: Recharts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Events By Month Chart */}
        <div className="lg:col-span-7 p-5 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Events Distribution by Month</h2>
              <p className="text-[11px] text-slate-500">Workshops, hackathons, and tournaments</p>
            </div>
            <TrendingUp className="w-4 h-4 text-purple-600" />
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={eventsByMonth} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748B' }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748B' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1E293B',
                    color: '#fff',
                    borderRadius: '8px',
                    fontSize: '12px',
                    border: 'none',
                  }}
                />
                <Bar dataKey="events" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Department Participation Breakdown */}
        <div className="lg:col-span-5 p-5 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Department Participation</h2>
              <p className="text-[11px] text-slate-500">Student enrollment distribution</p>
            </div>
          </div>

          <div className="h-48 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={departmentParticipation}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={3}
                  dataKey="count"
                  nameKey="department"
                >
                  {departmentParticipation.map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1E293B',
                    color: '#fff',
                    borderRadius: '8px',
                    fontSize: '12px',
                    border: 'none',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-[11px]">
            {departmentParticipation.slice(0, 4).map((d, i) => (
              <div key={d.department} className="flex items-center gap-1.5 truncate">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: COLORS[i % COLORS.length] }}
                />
                <span className="truncate text-slate-600">{d.department}:</span>
                <strong className="font-semibold text-slate-900 tabular-nums">{d.count}</strong>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Popular Clubs & Recent Activity Feeds */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Most Popular Clubs */}
        <div className="lg:col-span-6 p-5 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-slate-900">Most Popular Clubs</h2>
            <button
              onClick={() => onNavigate('explore')}
              className="text-xs font-semibold text-purple-600 hover:text-purple-700 flex items-center gap-1"
            >
              <span>Explore all</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {popularClubs.map((club, idx) => (
              <div
                key={club._id}
                className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100 hover:border-purple-200 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-md bg-purple-100 text-purple-700 font-bold flex items-center justify-center text-xs">
                    0{idx + 1}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">{club.name}</div>
                    <div className="text-[11px] text-slate-500">{club.category}</div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs font-semibold text-slate-700 tabular-nums">
                    {club.membersCount} members
                  </span>
                  <button
                    onClick={() => onNavigate('club-detail', { clubId: club._id })}
                    className="text-xs text-purple-600 hover:text-purple-700 font-medium"
                  >
                    View
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Announcements Feed */}
        <div className="lg:col-span-6 p-5 rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-purple-600" />
              <h2 className="text-sm font-bold text-slate-900">Latest Campus Announcements</h2>
            </div>
            <button
              onClick={() => onNavigate('announcements')}
              className="text-xs font-semibold text-purple-600 hover:text-purple-700 flex items-center gap-1"
            >
              <span>View feed</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {recentAnnouncements.map((ann) => (
              <div
                key={ann._id}
                className="p-3 rounded-lg border border-slate-100 bg-slate-50/70 space-y-1"
              >
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span className="font-medium text-purple-700">
                    {typeof ann.club === 'object' && ann.club?.name ? ann.club.name : 'Campus Announcement'}
                  </span>
                  <span>{new Date(ann.createdAt).toLocaleDateString()}</span>
                </div>
                <div className="text-xs font-bold text-slate-900">{ann.title}</div>
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{ann.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Upcoming Events Carousel / Strip */}
      <div className="p-5 rounded-xl border border-slate-200 bg-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Upcoming Events Calendar</h2>
            <p className="text-[11px] text-slate-500">Upcoming workshops and competitions</p>
          </div>
          <button
            onClick={() => onNavigate('events')}
            className="text-xs font-semibold text-purple-600 hover:text-purple-700 flex items-center gap-1"
          >
            <span>View all events</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {upcomingEvents.map((evt) => (
            <div
              key={evt._id}
              className="p-4 rounded-lg border border-slate-100 bg-slate-50/60 hover:border-purple-200 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="text-[11px] text-purple-700 font-semibold mb-1">
                  {typeof evt.club === 'object' ? evt.club.name : 'College Club'}
                </div>
                <h3 className="text-xs font-bold text-slate-900 mb-1 line-clamp-1">{evt.title}</h3>
                <div className="text-[11px] text-slate-500 mb-2">
                  {evt.date} · {evt.time}
                </div>
                <div className="text-[11px] text-slate-600 line-clamp-2 mb-3">
                  {evt.description}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between">
                <span className="text-[11px] text-slate-500 tabular-nums">
                  {evt.registrationsCount || 0} / {evt.capacity} registered
                </span>
                <button
                  onClick={() => onNavigate('events')}
                  className="text-xs font-semibold text-purple-600 hover:text-purple-700"
                >
                  Register →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
