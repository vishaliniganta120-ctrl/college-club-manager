import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { BookOpen, LogIn, AlertCircle, Sparkles } from 'lucide-react';

interface LoginPageProps {
  onNavigate: (page: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigate }) => {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please provide both email address and password.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      await login(email, password);
      onNavigate('dashboard');
    } catch (err: any) {
      setError(err.message || 'Failed to authenticate. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoFill = async (role: 'student' | 'coordinator' | 'admin') => {
    let demoEmail = '';
    let demoPwd = '';

    if (role === 'student') {
      demoEmail = 'alex.rivera@college.edu';
      demoPwd = 'Student@123';
    } else if (role === 'coordinator') {
      demoEmail = 'sarah.chen@college.edu';
      demoPwd = 'Coord@123';
    } else if (role === 'admin') {
      demoEmail = 'admin@college.edu';
      demoPwd = 'Admin@123';
    }

    setEmail(demoEmail);
    setPassword(demoPwd);
    try {
      setLoading(true);
      setError(null);
      await login(demoEmail, demoPwd);
      onNavigate('dashboard');
    } catch (err: any) {
      setError(err.message || 'Demo login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50/50 via-slate-50 to-slate-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <button
          onClick={() => onNavigate('landing')}
          className="inline-flex flex-col items-center gap-1.5 mb-4 group"
        >
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 via-rose-600 to-purple-700 flex items-center justify-center text-white shadow-md ring-2 ring-amber-300">
            <Sparkles className="w-6 h-6 text-amber-200" />
          </div>
          <span className="text-lg font-black text-slate-950 group-hover:text-amber-700 transition-colors">
            MALLA REDDY VISHWAVIDHYAPEETH
          </span>
          <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider">
            Campus Club & Fest Portal · Secunderabad
          </span>
        </button>
        <h2 className="text-2xl font-extrabold tracking-tight text-slate-900">Sign in to your account</h2>
        <p className="mt-1 text-xs text-slate-500">
          Access Bathukamma registrations, Dandiya passes, and club dashboards
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 sm:px-10 rounded-2xl border border-amber-200/80 shadow-md space-y-6">
          {/* Quick Demo Logins for easy evaluation */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-50 to-rose-50 border border-amber-200">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>1-Click Hackathon Evaluator Login:</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleDemoFill('student')}
                className="px-2 py-2 text-[11px] font-bold bg-white hover:bg-amber-100 text-amber-900 rounded-lg border border-amber-300 transition-colors text-center shadow-xs"
              >
                Student (Sai)
              </button>
              <button
                type="button"
                onClick={() => handleDemoFill('coordinator')}
                className="px-2 py-2 text-[11px] font-bold bg-white hover:bg-purple-100 text-purple-900 rounded-lg border border-purple-300 transition-colors text-center shadow-xs"
              >
                Coord (Sunitha)
              </button>
              <button
                type="button"
                onClick={() => handleDemoFill('admin')}
                className="px-2 py-2 text-[11px] font-bold bg-white hover:bg-rose-100 text-rose-900 rounded-lg border border-rose-300 transition-colors text-center shadow-xs"
              >
                Admin (Dean)
              </button>
            </div>
          </div>

          {error && (
            <div className="flex items-start gap-2.5 p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                College Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@college.edu"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-medium text-slate-700">Password</label>
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 transition-colors flex items-center justify-center gap-2 shadow-xs"
            >
              <LogIn className="w-4 h-4" />
              <span>{loading ? 'Authenticating...' : 'Sign In'}</span>
            </button>
          </form>

          <div className="text-center pt-2 border-t border-slate-100">
            <span className="text-xs text-slate-500">Need a student account? </span>
            <button
              onClick={() => onNavigate('register')}
              className="text-xs font-semibold text-purple-600 hover:text-purple-700 ml-1"
            >
              Register here
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
