import React, { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import { Membership, Club } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import {
  UserCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Users,
  Search,
  AlertCircle,
  Filter,
} from 'lucide-react';
import { EmptyState } from '../components/common/EmptyState.tsx';

export const MembershipManagementPage: React.FC = () => {
  const { user } = useAuth();
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [clubs, setClubs] = useState<Club[]>([]);
  const [selectedClubId, setSelectedClubId] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'pending' | 'approved'>('pending');
  const [loading, setLoading] = useState(true);
  const [actionId, setActionId] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [clubsRes, memsRes] = await Promise.all([
        api.clubs.getAll(),
        api.memberships.getCoordinatorList(),
      ]);
      setClubs(clubsRes);
      setMemberships(memsRes);
    } catch (err: any) {
      console.error('Failed to load membership requests:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const handleUpdateStatus = async (id: string, status: 'approved' | 'rejected') => {
    try {
      setActionId(id);
      await api.memberships.updateStatus(id, status);
      setNotification({
        text: `Membership request ${status === 'approved' ? 'approved' : 'rejected'}.`,
        type: 'success',
      });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Action failed', type: 'error' });
    } finally {
      setActionId(null);
    }
  };

  const handleRemoveMember = async (id: string) => {
    try {
      setActionId(id);
      await api.memberships.delete(id);
      setNotification({ text: 'Member removed from club.', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Action failed', type: 'error' });
    } finally {
      setActionId(null);
    }
  };

  const filteredMemberships = memberships.filter((m) => {
    if (m.status !== activeTab) return false;
    if (selectedClubId !== 'All') {
      const cId = typeof m.club === 'object' ? (m.club as any)._id : m.club;
      if (cId !== selectedClubId) return false;
    }
    return true;
  });

  const pendingCount = memberships.filter((m) => m.status === 'pending').length;
  const approvedCount = memberships.filter((m) => m.status === 'approved').length;

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Membership Management</h1>
        <p className="text-xs text-slate-500 mt-1">
          Review candidate applications, manage student rosters, and assign club participation status.
        </p>
      </div>

      {notification && (
        <div
          className={`p-3.5 rounded-lg text-xs flex items-center justify-between border ${
            notification.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600" />
            )}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="font-bold">
            ✕
          </button>
        </div>
      )}

      {/* Control bar: Tabs & Club Filter */}
      <div className="p-4 rounded-xl border border-slate-200 bg-white flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('pending')}
            className={`flex-1 sm:flex-initial px-4 py-2 font-medium rounded-md transition-colors flex items-center justify-center gap-2 ${
              activeTab === 'pending'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-amber-500" />
            <span>Pending Requests ({pendingCount})</span>
          </button>
          <button
            onClick={() => setActiveTab('approved')}
            className={`flex-1 sm:flex-initial px-4 py-2 font-medium rounded-md transition-colors flex items-center justify-center gap-2 ${
              activeTab === 'approved'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-purple-600" />
            <span>Active Members ({approvedCount})</span>
          </button>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={selectedClubId}
            onChange={(e) => setSelectedClubId(e.target.value)}
            className="w-full sm:w-auto px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-hidden focus:ring-2 focus:ring-purple-500"
          >
            <option value="All">All Clubs</option>
            {clubs.map((c) => (
              <option key={c._id} value={c._id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Table Container */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        {loading ? (
          <div className="p-12 flex justify-center items-center">
            <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filteredMemberships.length === 0 ? (
          <EmptyState
            icon={UserCheck}
            title={activeTab === 'pending' ? 'No pending requests' : 'No active members'}
            description={
              activeTab === 'pending'
                ? 'All candidate applications have been processed.'
                : 'No approved members in this club yet.'
            }
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-xs">
              <thead className="bg-slate-50/75">
                <tr>
                  <th className="px-5 py-3.5 text-left font-semibold text-slate-700">Student Candidate</th>
                  <th className="px-5 py-3.5 text-left font-semibold text-slate-700">Student ID</th>
                  <th className="px-5 py-3.5 text-left font-semibold text-slate-700">Department & Year</th>
                  <th className="px-5 py-3.5 text-left font-semibold text-slate-700">Applied Club</th>
                  <th className="px-5 py-3.5 text-left font-semibold text-slate-700">Request Date</th>
                  <th className="px-5 py-3.5 text-right font-semibold text-slate-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {filteredMemberships.map((m) => {
                  const student = typeof m.user === 'object' ? (m.user as any) : null;
                  const club = typeof m.club === 'object' ? (m.club as any) : null;
                  const isActing = actionId === m._id;

                  return (
                    <tr key={m._id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-4">
                        <div className="font-bold text-slate-900">{student?.name || 'Applicant'}</div>
                        <div className="text-[11px] text-slate-400">{student?.email}</div>
                      </td>
                      <td className="px-5 py-4 font-mono text-[11px] text-slate-600">
                        {student?.studentId || '—'}
                      </td>
                      <td className="px-5 py-4 text-slate-600">
                        <div>{student?.department || '—'}</div>
                        {student?.year && (
                          <div className="text-[11px] text-slate-400">Year {student.year}</div>
                        )}
                      </td>
                      <td className="px-5 py-4">
                        <div className="font-semibold text-purple-700">{club?.name || 'Club'}</div>
                        <div className="text-[11px] text-slate-400">{club?.category}</div>
                      </td>
                      <td className="px-5 py-4 text-slate-500 tabular-nums">
                        {new Date(m.joinedAt).toLocaleDateString()}
                      </td>
                      <td className="px-5 py-4 text-right">
                        {activeTab === 'pending' ? (
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleUpdateStatus(m._id, 'approved')}
                              disabled={isActing}
                              className="px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors border border-emerald-200 disabled:opacity-50"
                            >
                              Approve
                            </button>
                            <button
                              onClick={() => handleUpdateStatus(m._id, 'rejected')}
                              disabled={isActing}
                              className="px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors border border-rose-200 disabled:opacity-50"
                            >
                              Reject
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleRemoveMember(m._id)}
                            disabled={isActing}
                            className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          >
                            Remove
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
