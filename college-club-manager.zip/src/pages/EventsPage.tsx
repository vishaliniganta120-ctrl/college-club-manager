import React, { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import { ClubEvent, EventRegistration, Club } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Calendar,
  Clock,
  MapPin,
  Users,
  Search,
  CheckCircle2,
  XCircle,
  Ticket,
  AlertCircle,
  Plus,
} from 'lucide-react';
import { Modal } from '../components/common/Modal.tsx';
import { EmptyState } from '../components/common/EmptyState.tsx';

interface EventsPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const EventsPage: React.FC<EventsPageProps> = ({ onNavigate }) => {
  const { user, isAuthenticated } = useAuth();
  const [events, setEvents] = useState<ClubEvent[]>([]);
  const [clubs, setClubs] = useState<Club[]>([]);
  const [myRegistrations, setMyRegistrations] = useState<EventRegistration[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [clubFilter, setClubFilter] = useState('All');
  const [tab, setTab] = useState<'upcoming' | 'past'>('upcoming');
  const [notification, setNotification] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Attendees Modal (for coordinators/admins)
  const [selectedEventForAttendees, setSelectedEventForAttendees] = useState<ClubEvent | null>(null);
  const [attendees, setAttendees] = useState<EventRegistration[]>([]);
  const [attendeesLoading, setAttendeesLoading] = useState(false);

  // Create Event Modal (for coordinators/admins)
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [createForm, setCreateForm] = useState({
    title: '',
    description: '',
    club: '',
    date: '',
    time: '10:00 AM',
    venue: '',
    capacity: 50,
  });

  const loadData = async () => {
    try {
      setLoading(true);
      const [eventsRes, clubsRes] = await Promise.all([
        api.events.getAll(),
        api.clubs.getAll(),
      ]);
      setEvents(eventsRes);
      setClubs(clubsRes);

      if (isAuthenticated) {
        const regs = await api.registrations.getMy();
        setMyRegistrations(regs);
      }
    } catch (err: any) {
      console.error('Failed to load events:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [isAuthenticated]);

  const handleRegister = async (eventId: string) => {
    if (!isAuthenticated) {
      onNavigate('login');
      return;
    }
    try {
      await api.registrations.register(eventId);
      setNotification({ text: 'Seat successfully reserved for this event!', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to register', type: 'error' });
    }
  };

  const handleCancelRegistration = async (registrationId: string) => {
    try {
      await api.registrations.cancel(registrationId);
      setNotification({ text: 'Event registration cancelled.', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to cancel registration', type: 'error' });
    }
  };

  const openAttendeesModal = async (event: ClubEvent) => {
    setSelectedEventForAttendees(event);
    try {
      setAttendeesLoading(true);
      const res = await api.registrations.getByEvent(event._id);
      setAttendees(res);
    } catch (err: any) {
      console.error('Failed to load attendees:', err);
    } finally {
      setAttendeesLoading(false);
    }
  };

  const handleUpdateAttendance = async (regId: string, status: 'attended' | 'absent' | 'registered') => {
    try {
      await api.registrations.updateAttendance(regId, status);
      if (selectedEventForAttendees) {
        const res = await api.registrations.getByEvent(selectedEventForAttendees._id);
        setAttendees(res);
      }
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to update attendance', type: 'error' });
    }
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!createForm.club) {
      setNotification({ text: 'Please select a host club', type: 'error' });
      return;
    }
    try {
      await api.events.create(createForm);
      setIsCreateOpen(false);
      setNotification({ text: 'Event created successfully!', type: 'success' });
      setCreateForm({
        title: '',
        description: '',
        club: '',
        date: '',
        time: '10:00 AM',
        venue: '',
        capacity: 50,
      });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to create event', type: 'error' });
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];

  const filteredEvents = events.filter((evt) => {
    const isUpcoming = evt.date >= todayStr;
    if (tab === 'upcoming' && !isUpcoming) return false;
    if (tab === 'past' && isUpcoming) return false;

    const clubId = typeof evt.club === 'object' ? (evt.club as any)._id : evt.club;
    if (clubFilter !== 'All' && clubId !== clubFilter) return false;

    const query = searchQuery.toLowerCase();
    const titleMatch = evt.title.toLowerCase().includes(query);
    const descMatch = evt.description.toLowerCase().includes(query);
    const venueMatch = evt.venue.toLowerCase().includes(query);

    return titleMatch || descMatch || venueMatch;
  });

  const isOrganizer = user?.role === 'admin' || user?.role === 'coordinator';

  return (
    <div className="space-y-6">
      {/* Page Title & Organizer Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold text-amber-800 uppercase tracking-wider mb-1">
            MALLA REDDY VISHWAVIDHYAPEETH · CAMPUS EVENTS CALENDAR
          </div>
          <h1 className="text-2xl font-black tracking-tight text-slate-900">
            University Events & Festival Passes
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Reserve passes for the grand Dandiya Raas Night, Bathukamma floral celebrations, and technical hackathons.
          </p>
        </div>

        {isOrganizer && (
          <button
            onClick={() => setIsCreateOpen(true)}
            className="px-4 py-2 text-xs font-bold text-white bg-gradient-to-r from-amber-500 via-rose-600 to-purple-600 hover:from-amber-600 hover:to-purple-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 whitespace-nowrap self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Create Event</span>
          </button>
        )}
      </div>

      {/* Special Highlights Bar for Dandiya & Bathukamma */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-amber-100/90 via-rose-50 to-purple-50 border-2 border-amber-300/80 flex flex-col md:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-rose-600 flex items-center justify-center text-white font-bold text-lg shadow-xs shrink-0">
            🪔
          </div>
          <div>
            <div className="text-xs font-extrabold text-slate-900">
              Featured Cultural Festival: Mega Dandiya Raas (Oct 18) & Saddula Bathukamma (Oct 15)
            </div>
            <div className="text-[11px] text-slate-600">
              Free decorative Dandiya sticks, traditional Dhol beats, and ₹25,000 Bathukamma floral prize pool!
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              setSearchQuery('Dandiya');
              setTab('upcoming');
            }}
            className="px-3 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-lg transition-colors whitespace-nowrap shadow-xs"
          >
            Filter Dandiya Night
          </button>
          <button
            onClick={() => {
              setSearchQuery('Bathukamma');
              setTab('upcoming');
            }}
            className="px-3 py-1.5 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-lg transition-colors whitespace-nowrap shadow-xs"
          >
            Filter Bathukamma
          </button>
        </div>
      </div>

      {notification && (
        <div
          className={`p-3.5 rounded-lg text-xs flex items-center justify-between border ${
            notification.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600" />
            )}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="font-bold text-slate-400">
            ✕
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl border border-slate-200 bg-white flex flex-col md:flex-row gap-4 justify-between items-center">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search events by title or venue..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
          />
        </div>

        {/* Club Dropdown Filter & Upcoming/Past Segmented Tabs */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          <select
            value={clubFilter}
            onChange={(e) => setClubFilter(e.target.value)}
            className="px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500 bg-white text-slate-700"
          >
            <option value="All">All Clubs</option>
            {clubs.map((c) => (
              <option key={c._id} value={c._id}>
                {c.name}
              </option>
            ))}
          </select>

          <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs">
            <button
              onClick={() => setTab('upcoming')}
              className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
                tab === 'upcoming'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Upcoming
            </button>
            <button
              onClick={() => setTab('past')}
              className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
                tab === 'past'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Past
            </button>
          </div>
        </div>
      </div>

      {/* Events Grid */}
      {loading ? (
        <div className="p-12 flex justify-center items-center">
          <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filteredEvents.length === 0 ? (
        <EmptyState
          icon={Calendar}
          title={tab === 'upcoming' ? 'No upcoming events found' : 'No past events found'}
          description="Try switching filters or search terms."
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map((evt) => {
            const clubName =
              typeof evt.club === 'object' && evt.club ? (evt.club as any).name : 'Campus Society';

            // Check if user is registered
            const userRegistration = myRegistrations.find((r) => {
              const eId = typeof r.event === 'object' ? (r.event as any)._id : r.event;
              return eId === evt._id && r.status === 'confirmed';
            });

            const count = evt.registrationsCount || 0;
            const isFull = count >= evt.capacity;
            const pct = Math.min(100, Math.round((count / evt.capacity) * 100));

            return (
              <div
                key={evt._id}
                className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:border-purple-200 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Event Top Accent Strip */}
                  <div className="p-5 pb-3">
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="font-semibold text-purple-700">{clubName}</span>
                      <div className="flex items-center gap-1.5 text-slate-500 font-medium">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>{evt.date}</span>
                      </div>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 mb-2 leading-snug">
                      {evt.title}
                    </h3>
                    <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed mb-4">
                      {evt.description}
                    </p>

                    <div className="space-y-1.5 text-xs text-slate-500 pt-2 border-t border-slate-100">
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>{evt.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        <span className="truncate">{evt.venue}</span>
                      </div>
                    </div>
                  </div>

                  {/* Capacity Bar */}
                  <div className="px-5 py-2 bg-slate-50 border-t border-b border-slate-100">
                    <div className="flex items-center justify-between text-[11px] mb-1">
                      <span className="text-slate-500">Seat Capacity</span>
                      <span className="font-semibold text-slate-700 tabular-nums">
                        {count} / {evt.capacity} filled ({pct}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          isFull ? 'bg-rose-500' : pct > 75 ? 'bg-amber-500' : 'bg-purple-600'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Event Bottom Actions */}
                <div className="p-5 pt-3 flex items-center justify-between gap-3">
                  {/* Coordinator Attendees View Button */}
                  {isOrganizer && (
                    <button
                      onClick={() => openAttendeesModal(evt)}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
                    >
                      Attendees
                    </button>
                  )}

                  {/* User Registration state */}
                  {userRegistration ? (
                    <div className="flex items-center gap-2 ml-auto">
                      <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-200 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Registered</span>
                      </span>
                      <button
                        onClick={() => handleCancelRegistration(userRegistration._id)}
                        className="text-xs font-medium text-rose-600 hover:text-rose-700 hover:underline"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : isFull ? (
                    <span className="text-xs font-semibold text-slate-400 bg-slate-100 px-3 py-1.5 rounded-lg ml-auto">
                      Event Full
                    </span>
                  ) : (
                    <button
                      onClick={() => handleRegister(evt._id)}
                      className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg shadow-xs transition-colors ml-auto flex items-center gap-1.5"
                    >
                      <Ticket className="w-3.5 h-3.5" />
                      <span>Register Now</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Attendees Management Modal (for coordinators/admins) */}
      <Modal
        isOpen={!!selectedEventForAttendees}
        onClose={() => setSelectedEventForAttendees(null)}
        title={selectedEventForAttendees ? `Attendees: ${selectedEventForAttendees.title}` : 'Attendees'}
        maxWidth="lg"
      >
        <div className="space-y-4">
          <div className="text-xs text-slate-500">
            Total Registrations: <strong className="text-slate-800">{attendees.length}</strong> / Capacity: {selectedEventForAttendees?.capacity}
          </div>

          {attendeesLoading ? (
            <div className="p-8 text-center text-xs text-slate-500">Loading attendees list...</div>
          ) : attendees.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500 border border-dashed rounded-lg">
              No students have registered for this event yet.
            </div>
          ) : (
            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="min-w-full divide-y divide-slate-200 text-xs">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-3 py-2 text-left font-semibold text-slate-700">Student</th>
                    <th className="px-3 py-2 text-left font-semibold text-slate-700">Dept</th>
                    <th className="px-3 py-2 text-left font-semibold text-slate-700">Status</th>
                    <th className="px-3 py-2 text-right font-semibold text-slate-700">Attendance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {attendees.map((a) => {
                    const u = typeof a.user === 'object' ? (a.user as any) : null;
                    return (
                      <tr key={a._id} className="hover:bg-slate-50">
                        <td className="px-3 py-2.5">
                          <div className="font-semibold text-slate-900">{u?.name || 'Student'}</div>
                          <div className="text-[11px] text-slate-400">{u?.email}</div>
                        </td>
                        <td className="px-3 py-2.5 text-slate-600">{u?.department || '—'}</td>
                        <td className="px-3 py-2.5">
                          <span className="capitalize text-slate-700 font-medium">
                            {a.attendanceStatus}
                          </span>
                        </td>
                        <td className="px-3 py-2.5 text-right space-x-1">
                          <button
                            onClick={() => handleUpdateAttendance(a._id, 'attended')}
                            className="px-2 py-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded"
                          >
                            Attended
                          </button>
                          <button
                            onClick={() => handleUpdateAttendance(a._id, 'absent')}
                            className="px-2 py-1 text-[11px] font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded"
                          >
                            Absent
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </Modal>

      {/* Create Event Modal */}
      <Modal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        title="Schedule New Campus Event"
      >
        <form onSubmit={handleCreateEvent} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Host Club</label>
            <select
              required
              value={createForm.club}
              onChange={(e) => setCreateForm({ ...createForm, club: e.target.value })}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="">Select Club...</option>
              {clubs.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.name} ({c.category})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Title</label>
            <input
              type="text"
              required
              value={createForm.title}
              onChange={(e) => setCreateForm({ ...createForm, title: e.target.value })}
              placeholder="e.g. AI Prompting & Robotics Workshop"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Description</label>
            <textarea
              required
              rows={3}
              value={createForm.description}
              onChange={(e) => setCreateForm({ ...createForm, description: e.target.value })}
              placeholder="Outline schedule, agenda, speaker details..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Date</label>
              <input
                type="date"
                required
                value={createForm.date}
                onChange={(e) => setCreateForm({ ...createForm, date: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Time</label>
              <input
                type="text"
                required
                value={createForm.time}
                onChange={(e) => setCreateForm({ ...createForm, time: e.target.value })}
                placeholder="02:00 PM"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Venue</label>
              <input
                type="text"
                required
                value={createForm.venue}
                onChange={(e) => setCreateForm({ ...createForm, venue: e.target.value })}
                placeholder="Auditorium Hall B"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Capacity</label>
              <input
                type="number"
                min={1}
                required
                value={createForm.capacity}
                onChange={(e) => setCreateForm({ ...createForm, capacity: Number(e.target.value) })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsCreateOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg"
            >
              Schedule Event
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
