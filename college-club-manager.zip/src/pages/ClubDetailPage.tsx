import React, { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import { Club, ClubEvent, Announcement, Membership } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Compass,
  Calendar,
  Users,
  Clock,
  UserCheck,
  Megaphone,
  ArrowLeft,
  Plus,
  Mail,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { Modal } from '../components/common/Modal.tsx';
import { EmptyState } from '../components/common/EmptyState.tsx';

interface ClubDetailPageProps {
  clubId: string;
  onNavigate: (page: string, params?: any) => void;
}

export const ClubDetailPage: React.FC<ClubDetailPageProps> = ({
  clubId,
  onNavigate,
}) => {
  const { user, isAuthenticated } = useAuth();
  const [club, setClub] = useState<Club | null>(null);
  const [events, setEvents] = useState<ClubEvent[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [myMemberships, setMyMemberships] = useState<Membership[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [notification, setNotification] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // New Event Modal State
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [newEvent, setNewEvent] = useState({
    title: '',
    description: '',
    date: '',
    time: '10:00 AM',
    venue: '',
    capacity: 50,
  });

  // New Announcement Modal State
  const [isAnnModalOpen, setIsAnnModalOpen] = useState(false);
  const [newAnn, setNewAnn] = useState({
    title: '',
    message: '',
    priority: 'normal' as 'normal' | 'important' | 'urgent',
  });

  const loadData = async () => {
    try {
      setLoading(true);
      const [cRes, eRes, aRes] = await Promise.all([
        api.clubs.getById(clubId),
        api.events.getAll(),
        api.announcements.getAll(clubId),
      ]);
      setClub(cRes);
      // Filter events belonging to this club
      setEvents(
        eRes.filter((e) => {
          const cId = typeof e.club === 'object' ? (e.club as any)._id : e.club;
          return cId === clubId;
        })
      );
      setAnnouncements(aRes);

      if (isAuthenticated) {
        const mems = await api.memberships.getMy();
        setMyMemberships(mems);
      }
    } catch (err: any) {
      console.error('Failed to load club details:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [clubId, isAuthenticated]);

  if (loading || !club) {
    return (
      <div className="p-12 flex justify-center items-center">
        <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Check coordinator or admin status
  const isCoordinator =
    user?.role === 'admin' ||
    (typeof club.coordinator === 'object'
      ? (club.coordinator as any)._id === user?._id
      : club.coordinator === user?._id);

  // User membership status
  const currentMembership = myMemberships.find((m) => {
    const cId = typeof m.club === 'object' ? (m.club as any)._id : m.club;
    return cId === clubId;
  });

  const handleJoin = async () => {
    if (!isAuthenticated) {
      onNavigate('login');
      return;
    }
    try {
      setActionLoading(true);
      await api.memberships.request(clubId);
      setNotification({ text: 'Membership request submitted successfully!', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to submit membership request', type: 'error' });
    } finally {
      setActionLoading(false);
    }
  };

  const handleLeave = async () => {
    if (!currentMembership) return;
    try {
      setActionLoading(true);
      await api.memberships.delete(currentMembership._id);
      setNotification({ text: 'You have left the club.', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to leave club', type: 'error' });
    } finally {
      setActionLoading(false);
    }
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setActionLoading(true);
      await api.events.create({
        ...newEvent,
        club: clubId,
      });
      setIsEventModalOpen(false);
      setNewEvent({
        title: '',
        description: '',
        date: '',
        time: '10:00 AM',
        venue: '',
        capacity: 50,
      });
      setNotification({ text: 'Event created successfully!', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to create event', type: 'error' });
    } finally {
      setActionLoading(false);
    }
  };

  const handleCreateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setActionLoading(true);
      await api.announcements.create({
        ...newAnn,
        club: clubId,
      });
      setIsAnnModalOpen(false);
      setNewAnn({ title: '', message: '', priority: 'normal' });
      setNotification({ text: 'Announcement published successfully!', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to publish announcement', type: 'error' });
    } finally {
      setActionLoading(false);
    }
  };

  const coordObj = typeof club.coordinator === 'object' ? (club.coordinator as any) : null;

  return (
    <div className="space-y-8">
      {/* Back button */}
      <div>
        <button
          onClick={() => onNavigate('explore')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to all clubs</span>
        </button>
      </div>

      {notification && (
        <div
          className={`p-3.5 rounded-lg text-xs flex items-center justify-between border ${
            notification.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600" />
            )}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="font-bold text-slate-400">
            ✕
          </button>
        </div>
      )}

      {/* Hero Header Card */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="h-60 bg-slate-100 relative">
          {club.image ? (
            <img
              src={club.image}
              alt={club.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-purple-50 text-purple-600">
              <Compass className="w-16 h-16 stroke-1" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent flex items-end p-6">
            <div className="text-white space-y-1">
              <div className="text-xs font-semibold text-purple-300 uppercase tracking-wider">
                {club.category}
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold">{club.name}</h1>
            </div>
          </div>
        </div>

        <div className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-slate-100 bg-slate-50/50">
          <div className="flex flex-wrap items-center gap-6 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-purple-600" />
              <span>
                <strong className="font-bold text-slate-900 tabular-nums">{club.membersCount || 0}</strong> Active Members
              </span>
            </div>
            {coordObj && (
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-purple-600" />
                <span>Coordinator: <strong className="font-medium text-slate-900">{coordObj.name}</strong></span>
              </div>
            )}
          </div>

          {/* Membership Actions */}
          <div className="flex items-center gap-3">
            {isCoordinator && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsEventModalOpen(true)}
                  className="px-3 py-1.5 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Create Event</span>
                </button>
                <button
                  onClick={() => setIsAnnModalOpen(true)}
                  className="px-3 py-1.5 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>New Notice</span>
                </button>
              </div>
            )}

            {currentMembership?.status === 'approved' ? (
              <div className="flex items-center gap-2">
                <span className="px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-emerald-600" />
                  <span>Active Member</span>
                </span>
                <button
                  onClick={handleLeave}
                  disabled={actionLoading}
                  className="px-3 py-1.5 text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg border border-rose-200 transition-colors"
                >
                  Leave Club
                </button>
              </div>
            ) : currentMembership?.status === 'pending' ? (
              <span className="px-3.5 py-1.5 text-xs font-semibold text-amber-800 bg-amber-50 border border-amber-200 rounded-lg flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-600" />
                <span>Membership Pending</span>
              </span>
            ) : (
              <button
                onClick={handleJoin}
                disabled={actionLoading}
                className="px-5 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg shadow-xs transition-colors"
              >
                {actionLoading ? 'Submitting...' : 'Join Club'}
              </button>
            )}
          </div>
        </div>

        {/* Club Description */}
        <div className="p-6">
          <h2 className="text-sm font-bold text-slate-900 mb-2">About This Club</h2>
          <p className="text-xs text-slate-700 leading-relaxed max-w-4xl">{club.description}</p>
        </div>
      </div>

      {/* Grid: Events & Announcements */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Club Events */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900">Club Events & Workshops</h2>
            <span className="text-xs text-slate-500 tabular-nums">{events.length} listed</span>
          </div>

          {events.length === 0 ? (
            <EmptyState
              icon={Calendar}
              title="No upcoming events"
              description="This club has not scheduled any events yet."
            />
          ) : (
            <div className="space-y-3">
              {events.map((evt) => (
                <div
                  key={evt._id}
                  className="p-4 rounded-xl border border-slate-200 bg-white hover:border-purple-200 transition-colors flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2 text-xs text-purple-700 font-semibold mb-1">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{evt.date} · {evt.time}</span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900 mb-1">{evt.title}</h3>
                    <p className="text-xs text-slate-600 leading-relaxed mb-2">{evt.description}</p>
                    <div className="text-[11px] text-slate-500">
                      Venue: <strong>{evt.venue}</strong>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-500 tabular-nums">
                      {evt.registrationsCount || 0} / {evt.capacity} registered
                    </span>
                    <button
                      onClick={() => onNavigate('events')}
                      className="text-xs font-semibold text-purple-600 hover:text-purple-700"
                    >
                      Registration Details →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Club Announcements */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900">Club Announcements</h2>
            <span className="text-xs text-slate-500 tabular-nums">{announcements.length} notices</span>
          </div>

          {announcements.length === 0 ? (
            <EmptyState
              icon={Megaphone}
              title="No announcements yet"
              description="Check back later for coordinator notices and schedule updates."
            />
          ) : (
            <div className="space-y-3">
              {announcements.map((ann) => (
                <div
                  key={ann._id}
                  className="p-4 rounded-xl border border-slate-200 bg-white space-y-2"
                >
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="font-semibold text-purple-700 uppercase">
                      {ann.priority || 'Normal'}
                    </span>
                    <span>{new Date(ann.createdAt).toLocaleDateString()}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">{ann.title}</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">{ann.message}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Modal: Create Event */}
      <Modal
        isOpen={isEventModalOpen}
        onClose={() => setIsEventModalOpen(false)}
        title={`Add Event for ${club.name}`}
      >
        <form onSubmit={handleCreateEvent} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Event Title</label>
            <input
              type="text"
              required
              value={newEvent.title}
              onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
              placeholder="e.g. Annual Autonomous Hackathon"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Description</label>
            <textarea
              required
              rows={3}
              value={newEvent.description}
              onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
              placeholder="Provide event overview, requirements, and prizes..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Date</label>
              <input
                type="date"
                required
                value={newEvent.date}
                onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Time</label>
              <input
                type="text"
                required
                value={newEvent.time}
                onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
                placeholder="10:00 AM"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Venue</label>
              <input
                type="text"
                required
                value={newEvent.venue}
                onChange={(e) => setNewEvent({ ...newEvent, venue: e.target.value })}
                placeholder="Engineering Lab 202"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Capacity</label>
              <input
                type="number"
                min={1}
                required
                value={newEvent.capacity}
                onChange={(e) => setNewEvent({ ...newEvent, capacity: Number(e.target.value) })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsEventModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={actionLoading}
              className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg"
            >
              {actionLoading ? 'Creating...' : 'Create Event'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal: Create Announcement */}
      <Modal
        isOpen={isAnnModalOpen}
        onClose={() => setIsAnnModalOpen(false)}
        title={`Post Announcement for ${club.name}`}
      >
        <form onSubmit={handleCreateAnnouncement} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Headline</label>
            <input
              type="text"
              required
              value={newAnn.title}
              onChange={(e) => setNewAnn({ ...newAnn, title: e.target.value })}
              placeholder="e.g. Workshop schedule update"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Message</label>
            <textarea
              required
              rows={4}
              value={newAnn.message}
              onChange={(e) => setNewAnn({ ...newAnn, message: e.target.value })}
              placeholder="Full announcement content..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Priority</label>
            <select
              value={newAnn.priority}
              onChange={(e) => setNewAnn({ ...newAnn, priority: e.target.value as any })}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="normal">Normal</option>
              <option value="important">Important</option>
              <option value="urgent">Urgent</option>
            </select>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAnnModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={actionLoading}
              className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg"
            >
              {actionLoading ? 'Publishing...' : 'Publish'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
