import React, { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import { User, Club, ClubCategory } from '../types/index.ts';
import {
  ShieldAlert,
  Users,
  Compass,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertCircle,
  Database,
  RotateCcw,
} from 'lucide-react';
import { Modal } from '../components/common/Modal.tsx';

const CATEGORIES: ClubCategory[] = [
  'Technology',
  'Cultural & Arts',
  'Sports & Athletics',
  'Academic & Literary',
  'Entrepreneurship',
  'Media & Photography',
  'Social Impact',
];

export const AdminPanelPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [clubs, setClubs] = useState<Club[]>([]);
  const [systemHealth, setSystemHealth] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'users' | 'clubs' | 'system'>('clubs');
  const [notification, setNotification] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Club Create/Edit Modal State
  const [isClubModalOpen, setIsClubModalOpen] = useState(false);
  const [editingClub, setEditingClub] = useState<Club | null>(null);
  const [clubForm, setClubForm] = useState<{
    name: string;
    description: string;
    category: ClubCategory;
    coordinator: string;
    image?: string;
  }>({
    name: '',
    description: '',
    category: 'Technology',
    coordinator: '',
  });

  const loadData = async () => {
    try {
      setLoading(true);
      const [uRes, cRes, hRes] = await Promise.all([
        api.users.getAll(),
        api.clubs.getAll(),
        api.system.getHealth(),
      ]);
      setUsers(uRes);
      setClubs(cRes);
      setSystemHealth(hRes);
    } catch (err: any) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRoleChange = async (userId: string, newRole: string) => {
    try {
      await api.users.update(userId, { role: newRole });
      setNotification({ text: `User role updated to ${newRole}.`, type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to update role', type: 'error' });
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user? This will also remove their memberships and registrations.')) return;
    try {
      await api.users.delete(userId);
      setNotification({ text: 'User account removed.', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to delete user', type: 'error' });
    }
  };

  const openCreateClubModal = () => {
    setEditingClub(null);
    setClubForm({
      name: '',
      description: '',
      category: 'Technology',
      coordinator: users.find((u) => u.role === 'coordinator')?._id || users[0]?._id || '',
    });
    setIsClubModalOpen(true);
  };

  const openEditClubModal = (club: Club) => {
    setEditingClub(club);
    const coordId = typeof club.coordinator === 'object' ? (club.coordinator as any)._id : club.coordinator;
    setClubForm({
      name: club.name,
      description: club.description,
      category: club.category,
      coordinator: coordId,
      image: club.image,
    });
    setIsClubModalOpen(true);
  };

  const handleSaveClub = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingClub) {
        await api.clubs.update(editingClub._id, clubForm);
        setNotification({ text: 'Club details updated.', type: 'success' });
      } else {
        await api.clubs.create(clubForm);
        setNotification({ text: 'New club created successfully.', type: 'success' });
      }
      setIsClubModalOpen(false);
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to save club', type: 'error' });
    }
  };

  const handleDeleteClub = async (clubId: string) => {
    if (!confirm('Are you sure you want to delete this club? Associated events and memberships will be removed.')) return;
    try {
      await api.clubs.delete(clubId);
      setNotification({ text: 'Club deleted.', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to delete club', type: 'error' });
    }
  };

  const handleResetSeedData = async () => {
    if (!confirm('Reset database to initial sample hackathon data?')) return;
    try {
      await api.system.resetSeed();
      setNotification({ text: 'Database reset to default seed data successfully.', type: 'success' });
      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to reset seed data', type: 'error' });
    }
  };

  const coordinatorsList = users.filter((u) => u.role === 'coordinator' || u.role === 'admin');

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Platform Administration</h1>
          <p className="text-xs text-slate-500 mt-1">
            Institutional management panel for clubs, leadership coordinators, and system health.
          </p>
        </div>

        {activeTab === 'clubs' && (
          <button
            onClick={openCreateClubModal}
            className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg shadow-xs flex items-center gap-1.5 self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Club</span>
          </button>
        )}
      </div>

      {notification && (
        <div
          className={`p-3.5 rounded-lg text-xs flex items-center justify-between border ${
            notification.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600" />
            )}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="font-bold">
            ✕
          </button>
        </div>
      )}

      {/* Admin Tabs */}
      <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs w-full sm:w-auto">
        <button
          onClick={() => setActiveTab('clubs')}
          className={`px-4 py-2 font-medium rounded-md transition-colors flex items-center gap-2 ${
            activeTab === 'clubs'
              ? 'bg-white text-slate-900 shadow-xs font-semibold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Compass className="w-3.5 h-3.5 text-purple-600" />
          <span>Clubs Management ({clubs.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 font-medium rounded-md transition-colors flex items-center gap-2 ${
            activeTab === 'users'
              ? 'bg-white text-slate-900 shadow-xs font-semibold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5 text-indigo-600" />
          <span>Users & Roles ({users.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('system')}
          className={`px-4 py-2 font-medium rounded-md transition-colors flex items-center gap-2 ${
            activeTab === 'system'
              ? 'bg-white text-slate-900 shadow-xs font-semibold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Database className="w-3.5 h-3.5 text-blue-600" />
          <span>System & Database</span>
        </button>
      </div>

      {loading ? (
        <div className="p-12 flex justify-center items-center">
          <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : activeTab === 'clubs' ? (
        /* Clubs Table */
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-xs">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-5 py-3 text-left font-semibold text-slate-700">Club Name</th>
                  <th className="px-5 py-3 text-left font-semibold text-slate-700">Category</th>
                  <th className="px-5 py-3 text-left font-semibold text-slate-700">Coordinator</th>
                  <th className="px-5 py-3 text-left font-semibold text-slate-700">Members</th>
                  <th className="px-5 py-3 text-right font-semibold text-slate-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {clubs.map((c) => {
                  const coord = typeof c.coordinator === 'object' ? (c.coordinator as any)?.name : 'Unassigned';
                  return (
                    <tr key={c._id} className="hover:bg-slate-50">
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-slate-900">{c.name}</div>
                        <div className="text-[11px] text-slate-400 line-clamp-1">{c.description}</div>
                      </td>
                      <td className="px-5 py-3.5 font-medium text-purple-700">{c.category}</td>
                      <td className="px-5 py-3.5 text-slate-700">{coord}</td>
                      <td className="px-5 py-3.5 font-semibold text-slate-800 tabular-nums">
                        {c.membersCount || 0}
                      </td>
                      <td className="px-5 py-3.5 text-right space-x-2">
                        <button
                          onClick={() => openEditClubModal(c)}
                          className="p-1.5 text-slate-500 hover:text-purple-600 rounded hover:bg-slate-100"
                          title="Edit Club"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteClub(c._id)}
                          className="p-1.5 text-slate-500 hover:text-rose-600 rounded hover:bg-rose-50"
                          title="Delete Club"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : activeTab === 'users' ? (
        /* Users Table */
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-xs">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-5 py-3 text-left font-semibold text-slate-700">User Details</th>
                  <th className="px-5 py-3 text-left font-semibold text-slate-700">Student ID</th>
                  <th className="px-5 py-3 text-left font-semibold text-slate-700">Department</th>
                  <th className="px-5 py-3 text-left font-semibold text-slate-700">Role</th>
                  <th className="px-5 py-3 text-right font-semibold text-slate-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {users.map((u) => (
                  <tr key={u._id} className="hover:bg-slate-50">
                    <td className="px-5 py-3.5">
                      <div className="font-bold text-slate-900">{u.name}</div>
                      <div className="text-[11px] text-slate-400">{u.email}</div>
                    </td>
                    <td className="px-5 py-3.5 font-mono text-[11px] text-slate-600">
                      {u.studentId || '—'}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600">
                      {u.department || '—'} {u.year ? `(Yr ${u.year})` : ''}
                    </td>
                    <td className="px-5 py-3.5">
                      <select
                        value={u.role}
                        onChange={(e) => handleRoleChange(u._id, e.target.value)}
                        className="px-2 py-1 text-xs border border-slate-200 rounded font-semibold text-slate-700 bg-white"
                      >
                        <option value="student">Student</option>
                        <option value="coordinator">Coordinator</option>
                        <option value="admin">Administrator</option>
                      </select>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button
                        onClick={() => handleDeleteUser(u._id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50"
                        title="Delete User"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* System & Database Health */
        <div className="space-y-6">
          <div className="p-6 rounded-xl border border-slate-200 bg-white space-y-4">
            <h2 className="text-sm font-bold text-slate-900">Database Connection Status</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-slate-500 block mb-1">Current Persistence Engine:</span>
                <strong className="text-sm text-slate-900">{systemHealth?.database?.mode || 'Active'}</strong>
              </div>
              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-slate-500 block mb-1">MongoDB Atlas Connected:</span>
                <strong className="text-sm text-purple-700">
                  {systemHealth?.database?.connectedToAtlas ? 'YES (Live Cloud Cluster)' : 'Local File Persistence'}
                </strong>
              </div>
              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-slate-500 block mb-1">Server Heartbeat:</span>
                <strong className="text-sm text-emerald-600">Online 200 OK</strong>
              </div>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              When <code className="bg-slate-100 px-1 py-0.5 rounded text-purple-700 font-mono">MONGODB_URI</code> is
              configured in the server environment, Mongoose connects directly to MongoDB Atlas. If running offline or in demo mode,
              the integrated local document engine provides full CRUD, bcrypt hashing, JWT authentication, and file persistence.
            </p>
          </div>

          {/* Reset Seed Button */}
          <div className="p-6 rounded-xl border border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Reset Demo Database</h3>
              <p className="text-xs text-slate-500 mt-1">
                Restores the standard 9 users, 8 clubs, 6 events, and initial registrations for hackathon evaluation.
              </p>
            </div>
            <button
              onClick={handleResetSeedData}
              className="px-4 py-2 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg flex items-center gap-2 whitespace-nowrap self-start sm:self-auto"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Sample Data</span>
            </button>
          </div>
        </div>
      )}

      {/* Modal: Create/Edit Club */}
      <Modal
        isOpen={isClubModalOpen}
        onClose={() => setIsClubModalOpen(false)}
        title={editingClub ? `Edit Club: ${editingClub.name}` : 'Create New Club'}
      >
        <form onSubmit={handleSaveClub} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Club Name</label>
            <input
              type="text"
              required
              value={clubForm.name}
              onChange={(e) => setClubForm({ ...clubForm, name: e.target.value })}
              placeholder="e.g. Artificial Intelligence Society"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Category</label>
            <select
              value={clubForm.category}
              onChange={(e) => setClubForm({ ...clubForm, category: e.target.value as ClubCategory })}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500 bg-white"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Assigned Coordinator</label>
            <select
              required
              value={clubForm.coordinator}
              onChange={(e) => setClubForm({ ...clubForm, coordinator: e.target.value })}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="">Select Coordinator...</option>
              {coordinatorsList.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.name} ({c.email})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Description</label>
            <textarea
              required
              rows={3}
              value={clubForm.description}
              onChange={(e) => setClubForm({ ...clubForm, description: e.target.value })}
              placeholder="Describe the club's objectives, regular meetings, and target students..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsClubModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg"
            >
              {editingClub ? 'Save Changes' : 'Create Club'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
