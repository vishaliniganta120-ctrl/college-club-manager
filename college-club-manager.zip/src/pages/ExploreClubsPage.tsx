import React, { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import { Club, Membership, ClubCategory } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Search,
  Users,
  Compass,
  CheckCircle2,
  Clock,
  ArrowRight,
  UserCheck,
  AlertCircle,
} from 'lucide-react';
import { EmptyState } from '../components/common/EmptyState.tsx';

interface ExploreClubsPageProps {
  onNavigate: (page: string, params?: any) => void;
}

const CATEGORIES: ('All' | ClubCategory)[] = [
  'All',
  'Technology',
  'Cultural & Arts',
  'Sports & Athletics',
  'Academic & Literary',
  'Entrepreneurship',
  'Media & Photography',
  'Social Impact',
];

export const ExploreClubsPage: React.FC<ExploreClubsPageProps> = ({ onNavigate }) => {
  const { user, isAuthenticated } = useAuth();
  const [clubs, setClubs] = useState<Club[]>([]);
  const [myMemberships, setMyMemberships] = useState<Membership[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<'All' | ClubCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [requestingClubId, setRequestingClubId] = useState<string | null>(null);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      const clubsRes = await api.clubs.getAll();
      setClubs(clubsRes);

      if (isAuthenticated) {
        const memsRes = await api.memberships.getMy();
        setMyMemberships(memsRes);
      }
    } catch (err: any) {
      console.error('Failed to load clubs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [isAuthenticated]);

  const handleJoinRequest = async (clubId: string) => {
    if (!isAuthenticated) {
      onNavigate('login');
      return;
    }

    try {
      setRequestingClubId(clubId);
      setMessage(null);
      await api.memberships.request(clubId);
      setMessage({
        text: 'Membership request submitted successfully! Awaiting coordinator approval.',
        type: 'success',
      });
      // Refresh memberships
      const memsRes = await api.memberships.getMy();
      setMyMemberships(memsRes);
    } catch (err: any) {
      setMessage({
        text: err.message || 'Failed to submit request.',
        type: 'error',
      });
    } finally {
      setRequestingClubId(null);
    }
  };

  // Determine membership status for a club
  const getMembershipStatus = (clubId: string): 'none' | 'pending' | 'approved' | 'rejected' => {
    const mem = myMemberships.find((m) => {
      const cId = typeof m.club === 'object' ? (m.club as any)._id : m.club;
      return cId === clubId;
    });
    return mem ? mem.status : 'none';
  };

  // Filter clubs
  const filteredClubs = clubs.filter((club) => {
    const matchesCat = selectedCategory === 'All' || club.category === selectedCategory;
    const matchesQuery =
      club.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      club.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Explore Campus Clubs</h1>
        <p className="text-xs text-slate-500 mt-1">
          Browse all official registered student societies, organizations, and athletic clubs.
        </p>
      </div>

      {/* Notification Toast */}
      {message && (
        <div
          className={`p-3.5 rounded-lg text-xs flex items-center justify-between border ${
            message.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {message.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            )}
            <span>{message.text}</span>
          </div>
          <button
            onClick={() => setMessage(null)}
            className="text-slate-400 hover:text-slate-600 font-bold ml-4"
          >
            ✕
          </button>
        </div>
      )}

      {/* Search and Category Filters */}
      <div className="flex flex-col gap-4 bg-white p-4 rounded-xl border border-slate-200">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search clubs by keyword or topic..."
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-purple-500"
          />
        </div>

        {/* Category Segmented Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {CATEGORIES.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-xs font-semibold'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Clubs Grid */}
      {loading ? (
        <div className="p-12 flex justify-center items-center">
          <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filteredClubs.length === 0 ? (
        <EmptyState
          icon={Compass}
          title="No clubs found"
          description="Try adjusting your search query or switching the category filter."
          actionLabel="Reset filters"
          onAction={() => {
            setSelectedCategory('All');
            setSearchQuery('');
          }}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredClubs.map((club) => {
            const status = getMembershipStatus(club._id);
            const isRequesting = requestingClubId === club._id;
            const coordinator =
              typeof club.coordinator === 'object' && club.coordinator
                ? (club.coordinator as any).name
                : 'Faculty Lead';

            return (
              <div
                key={club._id}
                className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:border-purple-200 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Card Visual Header */}
                  <div className="h-44 bg-slate-100 relative">
                    {club.image ? (
                      <img
                        src={club.image}
                        alt={club.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-purple-50 text-purple-600">
                        <Compass className="w-12 h-12 stroke-1" />
                      </div>
                    )}
                    <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs text-slate-800 text-[11px] font-semibold px-2 py-0.5 rounded-md shadow-xs">
                      {club.category}
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-5">
                    <h3 className="text-base font-bold text-slate-900 mb-1.5">{club.name}</h3>
                    <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed mb-4">
                      {club.description}
                    </p>

                    <div className="space-y-1 text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                      <div className="flex items-center justify-between">
                        <span>Coordinator:</span>
                        <strong className="text-slate-700 font-medium">{coordinator}</strong>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Active Members:</span>
                        <strong className="text-slate-700 font-medium tabular-nums">
                          {club.membersCount || 0}
                        </strong>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="px-5 pb-5 pt-2 flex items-center gap-2">
                  <button
                    onClick={() => onNavigate('club-detail', { clubId: club._id })}
                    className="flex-1 py-2 px-3 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors text-center"
                  >
                    View Details
                  </button>

                  {/* Membership Button */}
                  {status === 'approved' ? (
                    <div className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 rounded-lg border border-emerald-200">
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>Member</span>
                    </div>
                  ) : status === 'pending' ? (
                    <div className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-amber-700 bg-amber-50 rounded-lg border border-amber-200">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Pending</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleJoinRequest(club._id)}
                      disabled={isRequesting}
                      className="py-2 px-3.5 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 rounded-lg shadow-xs transition-colors whitespace-nowrap"
                    >
                      {isRequesting ? 'Submitting...' : 'Join Club'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
