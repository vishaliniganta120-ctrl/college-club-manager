import React from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import {
  LayoutDashboard,
  Compass,
  Calendar,
  Users,
  UserCheck,
  Megaphone,
  BarChart3,
  ShieldAlert,
  UserCircle,
  X,
} from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  mobileOpen,
  onCloseMobile,
}) => {
  const { user } = useAuth();
  const role = user?.role || 'student';

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'explore', label: 'Explore Clubs', icon: Compass },
    { id: 'events', label: 'Events & Registration', icon: Calendar },
    ...(role === 'student'
      ? [{ id: 'my-clubs', label: 'My Clubs', icon: Users }]
      : []),
    ...(role === 'coordinator'
      ? [
          { id: 'my-clubs', label: 'My Assigned Clubs', icon: Users },
          { id: 'membership-requests', label: 'Membership Requests', icon: UserCheck },
        ]
      : []),
    ...(role === 'admin'
      ? [
          { id: 'membership-requests', label: 'All Memberships', icon: UserCheck },
          { id: 'admin-panel', label: 'Admin Panel', icon: ShieldAlert },
        ]
      : []),
    { id: 'announcements', label: 'Announcements', icon: Megaphone },
    { id: 'reports', label: 'Reports & Analytics', icon: BarChart3 },
    { id: 'profile', label: 'Profile & Settings', icon: UserCircle },
  ];

  const handleSelect = (id: string) => {
    onNavigate(id);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 w-64 bg-white border-r border-slate-200 transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full justify-between p-4">
          <div className="space-y-6">
            {/* Mobile close button */}
            <div className="flex items-center justify-between lg:hidden px-2 pb-2 border-b border-slate-100">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Navigation</span>
              <button
                onClick={onCloseMobile}
                className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Role Header Banner */}
            <div className="px-3 py-2.5 rounded-xl bg-gradient-to-r from-amber-50 to-rose-50 border border-amber-200">
              <div className="text-[10px] font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1">
                <span>🪔 MALLA REDDY VISHWAVIDHYAPEETH</span>
              </div>
              <div className="text-xs font-extrabold text-slate-900 capitalize mt-0.5">
                {role === 'admin' ? 'University Administrator' : role === 'coordinator' ? 'Faculty Club Coordinator' : 'Enrolled Student'}
              </div>
              {user?.department && (
                <div className="text-[10px] text-slate-600 truncate mt-0.5">
                  {user.department}
                </div>
              )}
            </div>

            {/* Navigation links */}
            <nav className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelect(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 text-left ${
                      isActive
                        ? 'bg-gradient-to-r from-amber-500 via-rose-600 to-purple-700 text-white shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-950 hover:bg-amber-50/60'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Footer note */}
          <div className="pt-3 border-t border-slate-100 px-2 text-[11px] text-slate-500 space-y-0.5">
            <div className="font-bold text-slate-700">MALLA REDDY VISHWAVIDHYAPEETH</div>
            <div className="text-[10px] text-amber-800 font-medium">Bathukamma & Dandiya Raas Hub</div>
          </div>
        </div>
      </aside>
    </>
  );
};
