import React from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { LogOut, User as UserIcon, Shield, Sparkles, BookOpen } from 'lucide-react';

interface NavbarProps {
  onNavigate: (page: string, params?: any) => void;
  currentPage: string;
  onOpenMobileMenu?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onNavigate,
  currentPage,
  onOpenMobileMenu,
}) => {
  const { user, logout, isAuthenticated } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          {isAuthenticated && (
            <button
              onClick={onOpenMobileMenu}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
              aria-label="Open navigation menu"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          )}
          <button
            onClick={() => onNavigate(isAuthenticated ? 'dashboard' : 'landing')}
            className="flex items-center gap-2.5 text-left focus:outline-hidden group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 via-rose-600 to-purple-700 flex items-center justify-center text-white shadow-sm ring-2 ring-amber-300/60">
              <Sparkles className="w-5 h-5 text-amber-200" />
            </div>
            <div>
              <span className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900 group-hover:text-amber-700 transition-colors whitespace-nowrap shrink-0 block leading-tight">
                MALLA REDDY VISHWAVIDHYAPEETH
              </span>
              <span className="text-[10px] font-semibold text-rose-700 uppercase tracking-wider block">
                College Club Manager · Dandiya & Bathukamma Mahotsav
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-5 text-xs font-semibold text-slate-600">
          {!isAuthenticated ? (
            <>
              <button
                onClick={() => onNavigate('landing')}
                className={`transition-colors whitespace-nowrap shrink-0 ${
                  currentPage === 'landing' ? 'text-amber-700 font-bold' : 'hover:text-slate-900'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => onNavigate('landing', { scroll: 'fest' })}
                className="text-rose-700 hover:text-rose-800 flex items-center gap-1 font-bold bg-rose-50 px-2.5 py-1 rounded-md border border-rose-200 transition-colors whitespace-nowrap shrink-0"
              >
                <span>🪔 Bathukamma & Dandiya</span>
              </button>
              <button
                onClick={() => onNavigate('explore')}
                className={`transition-colors whitespace-nowrap shrink-0 ${
                  currentPage === 'explore' ? 'text-amber-700 font-bold' : 'hover:text-slate-900'
                }`}
              >
                Clubs
              </button>
              <button
                onClick={() => onNavigate('events')}
                className={`transition-colors whitespace-nowrap shrink-0 ${
                  currentPage === 'events' ? 'text-amber-700 font-bold' : 'hover:text-slate-900'
                }`}
              >
                Events
              </button>
              <button
                onClick={() => onNavigate('landing', { scroll: 'contact' })}
                className="text-slate-600 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
              >
                Contact MRV
              </button>
            </>
          ) : (
            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate('events')}
                className="text-rose-700 font-bold flex items-center gap-1 bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200 text-xs"
              >
                <span>🪔 Bathukamma & Dandiya Fest</span>
              </button>
              <span className="text-xs text-slate-400 capitalize">{currentPage.replace('-', ' ')}</span>
            </div>
          )}
        </nav>

        {/* Zone 3: 1 primary action / user account */}
        <div className="flex items-center gap-3 shrink-0">
          {!isAuthenticated ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('login')}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-amber-100/50 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                Sign In
              </button>
              <button
                onClick={() => onNavigate('register')}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-amber-500 via-rose-600 to-purple-600 hover:from-amber-600 hover:to-purple-700 rounded-lg shadow-xs transition-colors whitespace-nowrap shrink-0"
              >
                Join Now
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate('profile')}
                className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 transition-colors text-left"
              >
                <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-700 font-semibold flex items-center justify-center text-xs">
                  {user?.name.charAt(0).toUpperCase()}
                </div>
                <div className="hidden sm:block">
                  <div className="text-xs font-semibold text-slate-900 leading-tight truncate max-w-[120px]">
                    {user?.name}
                  </div>
                  <div className="text-[10px] text-slate-500 capitalize">{user?.role}</div>
                </div>
              </button>
              <button
                onClick={() => {
                  logout();
                  onNavigate('landing');
                }}
                title="Sign out"
                className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                aria-label="Log out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
