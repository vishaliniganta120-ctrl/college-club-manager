import {
  User,
  Club,
  ClubEvent,
  Membership,
  EventRegistration,
  Announcement,
  DashboardReport,
} from '../types/index.ts';

const API_BASE = '/api';

class ApiService {
  private getToken(): string | null {
    return localStorage.getItem('ccm_token');
  }

  public setToken(token: string) {
    localStorage.setItem('ccm_token', token);
  }

  public clearToken() {
    localStorage.removeItem('ccm_token');
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = this.getToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers,
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      const message = data.message || `Request failed with status ${response.status}`;
      throw new Error(message);
    }

    return data as T;
  }

  // --- Auth ---
  auth = {
    login: (credentials: { email: string; password: string }) =>
      this.request<{ token: string; user: User; message: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      }),
    register: (userData: any) =>
      this.request<{ token: string; user: User; message: string }>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData),
      }),
    getMe: () => this.request<User>('/auth/me'),
  };

  // --- Users ---
  users = {
    getAll: () => this.request<User[]>('/users'),
    getById: (id: string) => this.request<User>(`/users/${id}`),
    update: (id: string, updates: any) =>
      this.request<{ message: string; user: User }>(`/users/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates),
      }),
    delete: (id: string) =>
      this.request<{ message: string }>(`/users/${id}`, {
        method: 'DELETE',
      }),
  };

  // --- Clubs ---
  clubs = {
    getAll: () => this.request<Club[]>('/clubs'),
    getById: (id: string) => this.request<Club>(`/clubs/${id}`),
    create: (clubData: Partial<Club>) =>
      this.request<{ message: string; club: Club }>('/clubs', {
        method: 'POST',
        body: JSON.stringify(clubData),
      }),
    update: (id: string, clubData: Partial<Club>) =>
      this.request<{ message: string; club: Club }>(`/clubs/${id}`, {
        method: 'PUT',
        body: JSON.stringify(clubData),
      }),
    delete: (id: string) =>
      this.request<{ message: string }>(`/clubs/${id}`, {
        method: 'DELETE',
      }),
  };

  // --- Memberships ---
  memberships = {
    getMy: () => this.request<Membership[]>('/memberships/my'),
    getCoordinatorList: (clubId?: string, status?: string) => {
      const query = new URLSearchParams();
      if (clubId) query.append('clubId', clubId);
      if (status) query.append('status', status);
      const qs = query.toString() ? `?${query.toString()}` : '';
      return this.request<Membership[]>(`/memberships/coordinator${qs}`);
    },
    getByClub: (clubId: string, status?: string) => {
      const qs = status ? `?status=${status}` : '';
      return this.request<Membership[]>(`/memberships/club/${clubId}${qs}`);
    },
    request: (clubId: string) =>
      this.request<{ message: string; membership: Membership }>('/memberships', {
        method: 'POST',
        body: JSON.stringify({ clubId }),
      }),
    updateStatus: (id: string, status: 'approved' | 'rejected') =>
      this.request<{ message: string; membership: Membership }>(`/memberships/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      }),
    delete: (id: string) =>
      this.request<{ message: string }>(`/memberships/${id}`, {
        method: 'DELETE',
      }),
  };

  // --- Events ---
  events = {
    getAll: () => this.request<ClubEvent[]>('/events'),
    getById: (id: string) => this.request<ClubEvent>(`/events/${id}`),
    create: (eventData: Partial<ClubEvent>) =>
      this.request<{ message: string; event: ClubEvent }>('/events', {
        method: 'POST',
        body: JSON.stringify(eventData),
      }),
    update: (id: string, eventData: Partial<ClubEvent>) =>
      this.request<{ message: string; event: ClubEvent }>(`/events/${id}`, {
        method: 'PUT',
        body: JSON.stringify(eventData),
      }),
    delete: (id: string) =>
      this.request<{ message: string }>(`/events/${id}`, {
        method: 'DELETE',
      }),
  };

  // --- Event Registrations ---
  registrations = {
    getMy: () => this.request<EventRegistration[]>('/event-registrations/my'),
    getByEvent: (eventId: string) =>
      this.request<EventRegistration[]>(`/event-registrations/event/${eventId}`),
    register: (eventId: string) =>
      this.request<{ message: string; registration: EventRegistration }>('/event-registrations', {
        method: 'POST',
        body: JSON.stringify({ eventId }),
      }),
    updateAttendance: (
      id: string,
      attendanceStatus: 'registered' | 'attended' | 'absent' | 'cancelled'
    ) =>
      this.request<{ message: string; registration: EventRegistration }>(
        `/event-registrations/${id}/attendance`,
        {
          method: 'PATCH',
          body: JSON.stringify({ attendanceStatus }),
        }
      ),
    cancel: (id: string) =>
      this.request<{ message: string }>(`/event-registrations/${id}`, {
        method: 'DELETE',
      }),
  };

  // --- Announcements ---
  announcements = {
    getAll: (clubId?: string) => {
      const qs = clubId ? `?clubId=${clubId}` : '';
      return this.request<Announcement[]>(`/announcements${qs}`);
    },
    create: (data: Partial<Announcement>) =>
      this.request<{ message: string; announcement: Announcement }>('/announcements', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    update: (id: string, data: Partial<Announcement>) =>
      this.request<{ message: string; announcement: Announcement }>(`/announcements/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    delete: (id: string) =>
      this.request<{ message: string }>(`/announcements/${id}`, {
        method: 'DELETE',
      }),
  };

  // --- Reports ---
  reports = {
    getDashboard: () => this.request<DashboardReport>('/reports/dashboard'),
    getParticipation: () => this.request<any>('/reports/participation'),
  };

  // --- System ---
  system = {
    getHealth: () => this.request<any>('/health'),
    resetSeed: () =>
      this.request<{ message: string }>('/seed/reset', {
        method: 'POST',
      }),
  };
}

export const api = new ApiService();
