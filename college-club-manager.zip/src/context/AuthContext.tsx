import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types/index.ts';
import { api } from '../services/api.ts';

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (userData: any) => Promise<User>;
  logout: () => void;
  updateUser: (updates: any) => Promise<User>;
  refreshUser: () => Promise<void>;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('ccm_token'));
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function loadCurrentUser() {
      const storedToken = localStorage.getItem('ccm_token');
      if (storedToken) {
        try {
          const me = await api.auth.getMe();
          setUser(me);
          setToken(storedToken);
        } catch (err) {
          console.warn('Session expired or invalid, logging out:', err);
          api.clearToken();
          setUser(null);
          setToken(null);
        }
      }
      setLoading(false);
    }

    loadCurrentUser();
  }, []);

  const login = async (email: string, password: string): Promise<User> => {
    const res = await api.auth.login({ email, password });
    api.setToken(res.token);
    setToken(res.token);
    setUser(res.user);
    return res.user;
  };

  const register = async (userData: any): Promise<User> => {
    const res = await api.auth.register(userData);
    api.setToken(res.token);
    setToken(res.token);
    setUser(res.user);
    return res.user;
  };

  const logout = () => {
    api.clearToken();
    setUser(null);
    setToken(null);
  };

  const updateUser = async (updates: any): Promise<User> => {
    if (!user) throw new Error('Not authenticated');
    const res = await api.users.update(user._id, updates);
    setUser(res.user);
    return res.user;
  };

  const refreshUser = async () => {
    if (token) {
      try {
        const me = await api.auth.getMe();
        setUser(me);
      } catch (err) {
        console.warn('Failed to refresh user', err);
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        login,
        register,
        logout,
        updateUser,
        refreshUser,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
