import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/layout/Navbar.tsx';
import { Sidebar } from './components/layout/Sidebar.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { LoginPage } from './pages/LoginPage.tsx';
import { RegisterPage } from './pages/RegisterPage.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { ExploreClubsPage } from './pages/ExploreClubsPage.tsx';
import { ClubDetailPage } from './pages/ClubDetailPage.tsx';
import { EventsPage } from './pages/EventsPage.tsx';
import { MyClubsPage } from './pages/MyClubsPage.tsx';
import { MembershipManagementPage } from './pages/MembershipManagementPage.tsx';
import { AnnouncementsPage } from './pages/AnnouncementsPage.tsx';
import { ReportsPage } from './pages/ReportsPage.tsx';
import { AdminPanelPage } from './pages/AdminPanelPage.tsx';
import { ProfileSettingsPage } from './pages/ProfileSettingsPage.tsx';

function MainApp() {
  const { isAuthenticated, login } = useAuth();
  const [currentPage, setCurrentPage] = useState<string>('landing');
  const [pageParams, setPageParams] = useState<any>({});
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const navigate = (page: string, params: any = {}) => {
    setCurrentPage(page);
    setPageParams(params);
    if (params?.scroll) {
      setTimeout(() => {
        const el = document.getElementById(params.scroll);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        } else {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      }, 50);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleQuickLogin = async (role: 'student' | 'coordinator' | 'admin') => {
    let email = '';
    let pwd = '';
    if (role === 'student') {
      email = 'alex.rivera@college.edu';
      pwd = 'Student@123';
    } else if (role === 'coordinator') {
      email = 'sarah.chen@college.edu';
      pwd = 'Coord@123';
    } else if (role === 'admin') {
      email = 'admin@college.edu';
      pwd = 'Admin@123';
    }
    try {
      await login(email, pwd);
      setCurrentPage('dashboard');
    } catch (err) {
      console.error('Demo login error:', err);
    }
  };

  // Render appropriate page content
  const renderContent = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage onNavigate={navigate} onQuickLogin={handleQuickLogin} />;
      case 'login':
        return <LoginPage onNavigate={navigate} />;
      case 'register':
        return <RegisterPage onNavigate={navigate} />;
      case 'dashboard':
        return <DashboardPage onNavigate={navigate} />;
      case 'explore':
        return <ExploreClubsPage onNavigate={navigate} />;
      case 'club-detail':
        return <ClubDetailPage clubId={pageParams.clubId || 'club_coding'} onNavigate={navigate} />;
      case 'events':
        return <EventsPage onNavigate={navigate} />;
      case 'my-clubs':
        return <MyClubsPage onNavigate={navigate} />;
      case 'membership-requests':
        return <MembershipManagementPage />;
      case 'announcements':
        return <AnnouncementsPage />;
      case 'reports':
        return <ReportsPage />;
      case 'admin-panel':
        return <AdminPanelPage />;
      case 'profile':
        return <ProfileSettingsPage />;
      default:
        return <DashboardPage onNavigate={navigate} />;
    }
  };

  // For unauthenticated standalone pages
  const isStandalonePage =
    !isAuthenticated ||
    currentPage === 'landing' ||
    currentPage === 'login' ||
    currentPage === 'register';

  if (isStandalonePage && currentPage !== 'dashboard') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col">
        <Navbar
          currentPage={currentPage}
          onNavigate={navigate}
          onOpenMobileMenu={() => setMobileSidebarOpen(true)}
        />
        <main className="flex-1">{renderContent()}</main>
      </div>
    );
  }

  // Dashboard layout for authenticated users
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar
        currentPage={currentPage}
        onNavigate={navigate}
        onOpenMobileMenu={() => setMobileSidebarOpen(!mobileSidebarOpen)}
      />

      <div className="flex-1 flex">
        <Sidebar
          currentPage={currentPage}
          onNavigate={navigate}
          mobileOpen={mobileSidebarOpen}
          onCloseMobile={() => setMobileSidebarOpen(false)}
        />

        <main className="flex-1 lg:pl-64 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
