export type UserRole = 'student' | 'coordinator' | 'admin';

export interface User {
  _id: string;
  name: string;
  email: string;
  studentId?: string;
  department?: string;
  year?: number;
  role: UserRole;
  avatar?: string;
  createdAt: string;
  updatedAt?: string;
}

export type ClubCategory =
  | 'Technology'
  | 'Cultural & Arts'
  | 'Sports & Athletics'
  | 'Academic & Literary'
  | 'Entrepreneurship'
  | 'Media & Photography'
  | 'Social Impact';

export interface Club {
  _id: string;
  name: string;
  description: string;
  category: ClubCategory;
  logo?: string;
  image?: string;
  coordinator: {
    _id: string;
    name: string;
    email: string;
    role?: string;
    department?: string;
  } | string;
  membersCount: number;
  createdAt: string;
}

export type MembershipStatus = 'pending' | 'approved' | 'rejected';

export interface Membership {
  _id: string;
  user: {
    _id: string;
    name: string;
    email: string;
    studentId?: string;
    department?: string;
    year?: number;
    role: string;
  } | string;
  club: {
    _id: string;
    name: string;
    category: ClubCategory;
    image?: string;
  } | string;
  status: MembershipStatus;
  joinedAt: string;
}

export interface ClubEvent {
  _id: string;
  title: string;
  description: string;
  club: {
    _id: string;
    name: string;
    category?: string;
  } | string;
  date: string;
  time: string;
  venue: string;
  capacity: number;
  registrationsCount: number;
  createdBy: {
    _id: string;
    name: string;
    email?: string;
  } | string;
  image?: string;
  createdAt: string;
}

export type AttendanceStatus = 'registered' | 'attended' | 'absent' | 'cancelled';

export interface EventRegistration {
  _id: string;
  user: {
    _id: string;
    name: string;
    email: string;
    studentId?: string;
    department?: string;
    year?: number;
  } | string;
  event: {
    _id: string;
    title: string;
    date: string;
    time: string;
    venue: string;
    club?: any;
  } | string;
  status: 'confirmed' | 'waitlist' | 'cancelled';
  attendanceStatus: AttendanceStatus;
  registeredAt: string;
}

export interface Announcement {
  _id: string;
  title: string;
  message: string;
  club?: {
    _id: string;
    name: string;
  } | string;
  priority?: 'normal' | 'important' | 'urgent';
  createdBy: {
    _id: string;
    name: string;
    role: string;
  } | string;
  createdAt: string;
}

export interface DashboardReport {
  summary: {
    totalClubs: number;
    totalStudents: number;
    upcomingEventsCount: number;
    totalRegistrations: number;
    pendingMemberships: number;
  };
  upcomingEvents: ClubEvent[];
  recentAnnouncements: Announcement[];
  departmentParticipation: { department: string; count: number }[];
  popularClubs: { _id: string; name: string; category: string; membersCount: number }[];
  eventsByMonth: { month: string; events: number }[];
  system?: {
    connectedToAtlas: boolean;
    mode: string;
    error: string | null;
  };
}
