# College Club Manager

A full-stack web application designed for colleges and universities to manage student clubs, registrations, workshops, memberships, and campus-wide activity reports. Built for students, club coordinators, and administrators.

---

## 🌟 Key Features

- **Three Role-Based Access Levels**:
  - **Student**: Discover clubs, filter by category, submit membership requests, register for upcoming events, cancel reservations, view announcements, and track membership participation.
  - **Club Coordinator**: Manage assigned student societies, review applicant requests with 1-click Approve/Reject, create events, monitor attendee lists, mark live attendance (`Attended` / `Absent`), and broadcast club bulletins.
  - **Administrator**: Complete platform oversight, manage all users and assign roles, create and edit clubs, audit event capacity, review institutional participation analytics, and monitor database health.
- **Visual Analytics**: Interactive Recharts dashboards featuring monthly event distributions, department-wise student participation, attendance ratios, and club membership density.
- **Robust Persistence & Authentication**:
  - Real MongoDB Atlas integration via Mongoose schemas.
  - Seamless offline/embedded fallback for instant zero-config demonstration and evaluation.
  - Secure bcrypt password hashing and JSON Web Tokens (JWT) stored in HTTP Bearer headers.
  - Server-enforced capacity limits and uniqueness constraints preventing duplicate registrations.

---

## 🛠️ Technology Stack

- **Frontend**: React 19, Vite, Tailwind CSS, Lucide React, Recharts.
- **Backend**: Node.js, Express.js.
- **Database**: MongoDB Atlas with Mongoose schemas (and built-in file-persistent document store fallback).
- **Security**: JWT (`jsonwebtoken`) and `bcryptjs` password hashing.

---

## 📋 Default Test & Demo Accounts

For immediate testing, use the following pre-seeded credentials:

| Role | Name | Email | Password | Details |
| :--- | :--- | :--- | :--- | :--- |
| **Administrator** | Dr. Eleanor Vance | `admin@college.edu` | `Admin@123` | Full administrative control |
| **Club Coordinator** | Sarah Chen | `sarah.chen@college.edu` | `Coord@123` | Coding & Robotics clubs |
| **Club Coordinator** | Marcus Vance | `marcus.vance@college.edu` | `Coord@123` | Sports & Athletics club |
| **Student** | Alex Rivera | `alex.rivera@college.edu` | `Student@123` | CS Dept, 3rd Year (CS2024-042) |
| **Student** | Priya Patel | `priya.patel@college.edu` | `Student@123` | Electronics Dept, 4th Year (EC2023-019) |

*(Note: 1-Click Demo Login buttons are also available directly on the Login page and Landing page for swift evaluation).*

---

## 🚀 Setup & Execution Guide (Windows / Mac / Linux)

### 1. Install Node.js
1. Download and install Node.js (v18 or v20+ recommended) from [nodejs.org](https://nodejs.org).
2. Open PowerShell or Command Prompt on Windows and verify:
   ```bash
   node -v
   npm -v
   ```

### 2. Set Up MongoDB Atlas Cluster (Optional for Cloud DB)
1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) and sign in or create a free account.
2. Create a new cluster (select the Free **M0** tier).
3. Under **Security > Database Access**, click **Add New Database User**:
   - Choose username and password (e.g., `ccm_user` and a strong password).
4. Under **Security > Network Access**, click **Add IP Address**:
   - For local development, choose **Allow Access From Anywhere (`0.0.0.0/0`)**.
5. Click **Clusters > Connect > Drivers (Node.js)** to copy your connection string:
   ```
   mongodb+srv://ccm_user:<password>@cluster0.mongodb.net/college_club_manager?retryWrites=true&w=majority
   ```

### 3. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Open `.env` in your text editor and update:
```env
PORT=3000
NODE_ENV=development
MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/college_club_manager?retryWrites=true&w=majority
JWT_SECRET=your_super_secret_jwt_key_college_club_manager_2026
```
*(If `MONGODB_URI` is left blank, the application automatically runs in embedded local persistence mode with pre-seeded data).*

### 4. Install Dependencies
```bash
npm install
```

### 5. Seed Sample Data
Populate the database with clubs, events, students, and coordinators:
```bash
npm run seed
```

### 6. Run the Application
Start the full-stack development server on port 3000:
```bash
npm run dev
```
Open your browser and navigate to:
```
http://localhost:3000
```

---

## 📁 Project Structure

```
college-club-manager/
├── server/
│   ├── config/
│   │   └── db.ts                # MongoDB Atlas connection & fallback manager
│   ├── controllers/
│   │   ├── authController.ts     # Register, login, getMe
│   │   ├── clubController.ts     # Club CRUD
│   │   ├── eventController.ts    # Event management & capacity
│   │   ├── membershipController.ts# Join requests & approval workflow
│   │   ├── registrationController.ts# Event ticket booking & attendance
│   │   ├── announcementController.ts# Campus & club bulletins
│   │   ├── reportController.ts   # Participation & dashboard analytics
│   │   └── userController.ts     # Profile and role assignments
│   ├── middleware/
│   │   └── auth.ts              # JWT verification & role authorization
│   ├── models/
│   │   ├── User.ts
│   │   ├── Club.ts
│   │   ├── Membership.ts
│   │   ├── Event.ts
│   │   ├── EventRegistration.ts
│   │   └── Announcement.ts
│   ├── routes/                  # Express route routers
│   ├── scripts/
│   │   └── seed.ts              # Database seeding script
│   ├── services/
│   │   └── dataStore.ts         # Unified persistence & business logic
│   └── types/
│       └── index.ts
├── src/
│   ├── assets/images/           # Generated collegiate campus assets
│   ├── components/
│   │   ├── common/              # Modal, EmptyState, Badges
│   │   └── layout/              # Navbar, Sidebar, TopBar
│   ├── context/
│   │   └── AuthContext.tsx      # Authentication state and tokens
│   ├── pages/
│   │   ├── LandingPage.tsx      # Campus showcase, hero, features
│   │   ├── LoginPage.tsx        # Authentication & 1-click demo logins
│   │   ├── RegisterPage.tsx     # Student & coordinator sign-up
│   │   ├── DashboardPage.tsx    # Key metrics & Recharts graphs
│   │   ├── ExploreClubsPage.tsx # Club discovery with category filters
│   │   ├── ClubDetailPage.tsx   # Detailed society view & events
│   │   ├── EventsPage.tsx       # Schedule, seat limits, registration
│   │   ├── MyClubsPage.tsx      # Joined clubs & participation
│   │   ├── MembershipManagementPage.tsx # Review requests (Coordinators)
│   │   ├── AnnouncementsPage.tsx# Bulletins and news broadcast
│   │   ├── ReportsPage.tsx      # Institutional analytics charts
│   │   ├── AdminPanelPage.tsx   # User & club management
│   │   └── ProfileSettingsPage.tsx # User profile & password changes
│   ├── services/
│   │   └── api.ts               # Typed client REST API service
│   ├── types/
│   │   └── index.ts
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── server.ts                    # Main unified Express server entry point
├── package.json
├── .env.example
└── README.md
```

---

## 🛠️ Troubleshooting

- **MongoDB Atlas Connection Error**: Ensure your current IP is whitelisted under Atlas **Network Access** (or set to `0.0.0.0/0` for development). Also verify your password in `MONGODB_URI` does not contain unescaped special characters.
- **Port 3000 in use**: You can change `PORT=3001` in your `.env` file or kill the existing process occupying port 3000 (`npx kill-port 3000`).
- **Token expired**: Clear your browser localStorage or log in again using one of the demo accounts.
