import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

import { connectDB, getDBStatus } from './server/config/db.ts';
import { store } from './server/services/dataStore.ts';
import authRoutes from './server/routes/authRoutes.ts';
import userRoutes from './server/routes/userRoutes.ts';
import clubRoutes from './server/routes/clubRoutes.ts';
import membershipRoutes from './server/routes/membershipRoutes.ts';
import eventRoutes from './server/routes/eventRoutes.ts';
import registrationRoutes from './server/routes/registrationRoutes.ts';
import announcementRoutes from './server/routes/announcementRoutes.ts';
import reportRoutes from './server/routes/reportRoutes.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(cors());
app.use(express.json());

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/clubs', clubRoutes);
app.use('/api/memberships', membershipRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/event-registrations', registrationRoutes);
app.use('/api/announcements', announcementRoutes);
app.use('/api/reports', reportRoutes);

// Health & System Info API
app.get('/api/health', (_req, res) => {
  const dbStatus = getDBStatus();
  res.json({
    status: 'ok',
    appName: 'College Club Manager',
    time: new Date().toISOString(),
    database: dbStatus,
  });
});

// Reset / Re-seed sample data endpoint (convenient for grading/demo)
app.post('/api/seed/reset', (_req, res) => {
  store.resetSeedData();
  res.json({ message: 'Database reset to initial sample state with 9 users, 8 clubs, and 6 events.' });
});

// Centralized error handler
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Unhandled server error:', err);
  res.status(err.status || 500).json({
    message: err.message || 'An unexpected server error occurred.',
  });
});

async function startServer() {
  // Attempt MongoDB Atlas connection
  await connectDB();

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    // Mount Vite dev server middlewares
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🎓 College Club Manager running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
